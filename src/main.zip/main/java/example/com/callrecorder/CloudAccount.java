package example.com.callrecorder;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.location.places.Places;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import example.com.callrecorder.Googledrive.BaseDemoActivity;
import example.com.callrecorder.Googledrive.CreateEmptyFileActivity;
import example.com.callrecorder.Googledrive.Drive_activity;
import example.com.callrecorder.Utils.PreferenceSettings;
import example.com.callrecorder.callrecordersdata.SyncService;


public class CloudAccount extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {


    ImageView switchwifi, switchsave;
    /*making folder in google drive*/

    Switch switch1, switch_2, switch_3;
    LinearLayout ll_login, tv_sync;
    TextView cloudlogin, cloudlogindetails;
    PreferenceSettings mPreferenceSettings;

    public static Context test;
    public static boolean fileOperation = false;
    String sw_wifi="false",sw_save="false";

    private static GoogleApiClient mGoogleApiClient;
    private ProgressDialog mProgressDialog;
    private static final int RC_SIGN_IN = 007;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloud_account);
        mPreferenceSettings = new PreferenceSettings(CloudAccount.this);
//        switch_2 = (Switch) findViewById(R.id.wifionly);
//        switch_3 = (Switch) findViewById(R.id.autosave);
        cloudlogin = (TextView) findViewById(R.id.tv_logincloud);
        cloudlogindetails = (TextView) findViewById(R.id.tv_loginclouddetails);
        switchwifi = (ImageView) findViewById(R.id.switch_wifi);
        switchsave = (ImageView) findViewById(R.id.switch_save);
        switchwifi.setOnClickListener(this);
        switchsave.setOnClickListener(this);

        test = CloudAccount.this;
        inittoolbar();

        ll_login = (LinearLayout) findViewById(R.id.ll_logout);
        tv_sync = (LinearLayout) findViewById(R.id.tv_sync);
        ll_login.setOnClickListener(this);
        tv_sync.setOnClickListener(this);

        if (mPreferenceSettings.getDriveLogin() == true) {
//            cloudlogin.setText("Logout");
            cloudlogin.setText(getResources().getString(R.string.Logout));
        } else {
//            cloudlogin.setText("Login");
            cloudlogin.setText(getResources().getString(R.string.Login));

        }
        selectswich();

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(com.google.android.gms.auth.api.Auth.GOOGLE_SIGN_IN_API, gso)
                .build();


    }

    public void selectswich() {
//        try {
//            if (mPreferenceSettings.getWifionly()) {
//                switch_2.setChecked(true);
//            }
//            if (mPreferenceSettings.getAUTOSAVE()) {
//                switch_3.setChecked(true);
//            }
//        } catch (Exception ex) {
//            Log.e("error", "" + ex);
//        }
        try {
            if (mPreferenceSettings.getWifionly()) {
                Log.e("wifi",""+mPreferenceSettings.getWifionly());
                switchwifi.setImageResource(R.drawable.on_switch);
            }else if(mPreferenceSettings.getWifionly()==false){
                Log.e("wifi","else"+mPreferenceSettings.getWifionly());
                switchwifi.setImageResource(R.drawable.off_switch);
            }
            if (mPreferenceSettings.getAUTOSAVE()) {
//                Log.e("save",""+mPreferenceSettings.getWifionly());
                switchsave.setImageResource(R.drawable.on_switch);
            }else if(mPreferenceSettings.getAUTOSAVE()==false){
//                Log.e("save","else"+mPreferenceSettings.getWifionly());
                switchsave.setImageResource(R.drawable.off_switch);
            }
        } catch (Exception ex) {
            Log.e("error", "" + ex);
        }
    }

    public void inittoolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.Cloudaccount));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }

//    public void onSwitchClicked(View view) {
//        switch (view.getId()) {
//            /*case R.id.switch1:
//                if (switch1.isChecked()) {
//                    mPreferenceSettings.setSELULARDATA_WARNIG(true);
//                    Log.e("wifi",""+mPreferenceSettings.getSELULARDATA_WARNIG());
//                    Toast.makeText(this, "Switch 1 check ON by click on it", Toast.LENGTH_SHORT).show();
//                } else {
//                    mPreferenceSettings.setSELULARDATA_WARNIG(true);
//                    Toast.makeText(this, "Switch 1", Toast.LENGTH_SHORT).show();
//                }
//                break;*/
//            case R.id.wifionly:
//                if (switch_2.isChecked()) {
//                    mPreferenceSettings.setWifionly(true);
//                } else {
//                    mPreferenceSettings.setWifionly(false);
//                }
//                break;
//            case R.id.autosave:
//                if (switch_3.isChecked()) {
//                    mPreferenceSettings.setAUTOSAVE(true);
//                } else {
//                    mPreferenceSettings.setAUTOSAVE(false);
//                }
//                break;
//        }
//    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_logout:
//                Intent i = new Intent(CloudAccount.this, Drive_activity.class);
//                startActivity(i);


                if (mPreferenceSettings.getDriveLogin() == true) {
                    LogOutdialogAlert();


                } else {

//                    GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                            .requestEmail()
//                            .build();
//
//                    mGoogleApiClient = new GoogleApiClient.Builder(this)
//                            .enableAutoManage(this, this)
//                            .addApi(com.google.android.gms.auth.api.Auth.GOOGLE_SIGN_IN_API, gso)
//                            .build();


                    mPreferenceSettings.setDriveLogin(true);
                    MainActivity.SaveFlag = true;
                    Intent signInIntent = com.google.android.gms.auth.api.Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
                    startActivityForResult(signInIntent, RC_SIGN_IN);
                    cloudlogin.setText(getResources().getString(R.string.Logout));
                    cloudlogindetails.setText(getResources().getString(R.string.Logoutgoogledrive));




//                    Intent i = new Intent(CloudAccount.this, CreateEmptyFileActivity.class);
//                    startActivity(i);
                }

//


                break;
            case R.id.switch_wifi:
                if(sw_wifi.equalsIgnoreCase("true")){
                    Log.e("wifi",""+sw_wifi);
                    sw_wifi="false";
                    mPreferenceSettings.setWifionly(false);
                    switchwifi.setImageResource(R.drawable.off_switch);
                }else if(sw_wifi.equalsIgnoreCase("false")){
                    Log.e("wifi","else"+sw_wifi);
                    sw_wifi="true";
                    mPreferenceSettings.setWifionly(true);
                    switchwifi.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.switch_save:
                if(sw_save.equalsIgnoreCase("true")){
                    Log.e("save",""+sw_save);
                    sw_save="false";
                    mPreferenceSettings.setAUTOSAVE(false);
                    switchsave.setImageResource(R.drawable.off_switch);
                }else if(sw_save.equalsIgnoreCase("false")){
                    Log.e("save","else"+sw_save);
                    sw_save="true";
                    mPreferenceSettings.setAUTOSAVE(true);
                    switchsave.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.tv_sync:
                dialogBox();
                break;
        }
    }


    public void LogOutdialogAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(CloudAccount.this);

        // Setting Dialog Title
        alertDialog.setTitle("Logout...");

        // Setting Dialog Message
        alertDialog.setMessage("Are you sure you want Logout?");


        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                cloudlogin.setText("Login");

                mPreferenceSettings.setDriveLogin(false);
                MainActivity.SaveFlag = true;
//                MainActivity.logout();
                cloudlogindetails.setText("Login in your googledrive");
                signOut();
                // Write your code here to invoke YES event
            }
        });

        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to invoke NO event
//                Toast.makeText(getApplicationContext(), "You clicked on NO", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

       /*For write contetnt in file in google drive*/

    public void dialogBox() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Sync recording now?");
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        if(mPreferenceSettings.getDriveLogin()) {
                            Intent myIntent2 = new Intent(CloudAccount.this, SyncService.class);
                            startService(myIntent2);
                        }else {
                            Toast.makeText(CloudAccount.this, "Please login in google drive", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        alertDialogBuilder.setNegativeButton("No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage("loading");
            mProgressDialog.setIndeterminate(true);
        }

        mProgressDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPreferenceSettings.getDriveLogin() == true) {
//            cloudlogin.setText("Logout");
            cloudlogin.setText(getResources().getString(R.string.Logout));

        } else {
//            cloudlogin.setText("Login");
            cloudlogin.setText(getResources().getString(R.string.Login));

        }

    }

    @Override
    protected void onStop() {
        super.onStop();

        super.onPause();
    }



    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d("Cloud", "onConnectionFailed:" + connectionResult);
        finish();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = com.google.android.gms.auth.api.Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            handleSignInResult(result);
        }
    }

//    @Override
//    public void onStart() {
//        super.onStart();
//
//        OptionalPendingResult<GoogleSignInResult> opr = com.google.android.gms.auth.api.Auth
//                .GoogleSignInApi.silentSignIn(mGoogleApiClient);
//        if (opr.isDone()) {
//            // If the user's cached credentials are valid, the OptionalPendingResult will be "done"
//            // and the GoogleSignInResult will be available instantly.
//            Log.d("Cloud", "Got cached sign-in");
//            GoogleSignInResult result = opr.get();
////            handleSignInResult(result);
//        } else {
//            // If the user has not previously signed in on this device or the sign-in has expired,
//            // this asynchronous branch will attempt to sign in the user silently.  Cross-device
//            // single sign-on will occur in this branch.
//            showProgressDialog();
//            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
//                @Override
//                public void onResult(GoogleSignInResult googleSignInResult) {
////                    hideProgressDialog();
//                    handleSignInResult(googleSignInResult);
//                }
//            });
//        }
//    }


    private void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.hide();
        }
    }

    private void signOut() {
        com.google.android.gms.auth.api.Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
//                        updateUI(false);
                        mGoogleApiClient.clearDefaultAccountAndReconnect();
                    }
                });
    }

    private void revokeAccess() {
        com.google.android.gms.auth.api.Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
//                        updateUI(false);
                    }
                });
    }

    private void handleSignInResult(GoogleSignInResult result) {
        Log.d("", "handleSignInResult:" + result.isSuccess());
        if (result.isSuccess()) {
            // Signed in successfully, show authenticated UI.
            GoogleSignInAccount acct = result.getSignInAccount();

            Log.e("", "displayname: " + acct.getDisplayName());
            Log.e("", "token id: " + acct.getId());
            Log.e("", "token: tokenid " + acct.getIdToken());
            Log.e("", "token: server auth" + acct.getServerAuthCode());
            Log.e("", "token: granted" + acct.getGrantedScopes());
            Log.e("", "token: given name" + acct.getFamilyName());

            finish();
//            String personName = acct.getDisplayName();
//            String personPhotoUrl = acct.getPhotoUrl().toString();
//            String email = acct.getEmail();

//            Log.e(TAG, "Name: " + personName + ", email: " + email
//            );
//
//            txtName.setText(personName);
//            txtEmail.setText(email);
//            Glide.with(getApplicationContext()).load(personPhotoUrl)
//                    .thumbnail(0.5f)
//                    .crossFade()
//                    .diskCacheStrategy(DiskCacheStrategy.ALL)
//                    .into(imgProfilePic);

//            updateUI(true);
        } else {
            // Signed out, show unauthenticated UI.
//            updateUI(false);
        }
    }
//
//    public static void saveFiletoDrive(final String path) {
//        // Start by creating a new contents, and setting a callback.
//        Drive.DriveApi.newDriveContents(mGoogleApiClient).setResultCallback(
//                new ResultCallback<DriveApi.DriveContentsResult>() {
//                    @Override
//                    public void onResult(DriveApi.DriveContentsResult result) {
//                        // If the operation was not successful, we cannot do
//                        // anything
//                        // and must
//                        // fail.
////                        String fname = String.valueOf(Uri.parse("android.resource://example.com.googledriveapi/" + R.raw.d9_bus_horn));
////                        String path = "/mnt/sdcard/facebook_ringtone_pop.m4a";
//
//                        String path2 = String.valueOf(Environment.getExternalStorageDirectory() + "/callrecorder/10-channel3--1259189495.3gpp");
////                        String path = String.valueOf(Environment.getExternalStorageDirectory() + "/Test.mp3");
//
////                        String uri = String.valueOf(getResources().openRawResource(getResources().getIdentifier("d9_bus_horn", "raw", getPackageName())));
//                        //      String uri = String.valueOf(getResources().getIdentifier(path + "/facebook_ringtone_pop.m4a", "raw", getPackageName()));
//
//                        try {
//                            file = new File(path);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
////                        file = new File(uri);
//                        if (!result.getStatus().isSuccess()) {
//                            Log.i(TAG, "Failed to create new contents.");
//                            return;
//                        }
//                        Log.i(TAG, "Connection successful, creating new contents...");
//                        // Otherwise, we can write our data to the new contents.
//                        // Get an output stream for the contents.
//                        OutputStream outputStream = result.getDriveContents()
//                                .getOutputStream();
//                        FileInputStream fis;
//                        try {
//                            fis = new FileInputStream(file.getPath());
//                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                            byte[] buf = new byte[1024];
//                            int n;
//                            while (-1 != (n = fis.read(buf)))
//                                baos.write(buf, 0, n);
//                            byte[] photoBytes = baos.toByteArray();
//                            outputStream.write(photoBytes);
//
//                            outputStream.close();
//                            outputStream = null;
//                            fis.close();
//                            fis = null;
//
//                        } catch (FileNotFoundException e) {
//                            Log.w(TAG, "FileNotFoundException: " + e.getMessage());
//                        } catch (IOException e1) {
//                            Log.w(TAG, "Unable to write file contents." + e1.getMessage());
//                        }
//
//                        String title = file.getName();
//                        MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
//                                .setMimeType("audio/*").setTitle(title).build();
//
////                        if (mime.equals(MIME_PHOTO)) {
////                            if (VERBOSE)
////                                Log.i(TAG, "Creating new photo on Drive (" + title
////                                        + ")");
////                            Drive.DriveApi.getFolder(mDriveClient,
////                                    mPicFolderDriveId).createFile(mDriveClient,
////                                    metadataChangeSet,
////                                    result.getDriveContents());
////                        } else
////                        if (mime.equals(MIME_VIDEO)) {
//                        Log.i(TAG, "Creating new video on Drive (" + title
//                                + ")");
//                        Drive.DriveApi.getRootFolder(mGoogleApiClient).createFile(mGoogleApiClient,
//                                metadataChangeSet,
//                                result.getDriveContents());
////                        }
//
////                        if (file.delete()) {
////                            if (VERBOSE)
////                                Log.d(TAG, "Deleted " + file.getName() + " from sdcard");
////                        } else {
////                            Log.w(TAG, "Failed to delete " + file.getName() + " from sdcard");
////                        }
//                    }
//                });
//    }

/*    public static void saveFiletoDrive(final String path) {
        // Start by creating a new contents, and setting a callback.

        Drive.DriveApi.newDriveContents(mGoogleApiClient).setResultCallback(
                new ResultCallback<DriveApi.DriveContentsResult>() {
                    @Override
                    public void onResult(DriveApi.DriveContentsResult result) {
                        // If the operation was not successful, we cannot do
                        // anything
                        // and must
                        // fail.
//                        String fname = String.valueOf(Uri.parse("android.resource://example.com.googledriveapi/" + R.raw.d9_bus_horn));
//                        String path = "/mnt/sdcard/facebook_ringtone_pop.m4a";
//                        String path = String.valueOf(Environment.getExternalStorageDirectory()+"/Test.mp3");
//                        String uri = String.valueOf(getResources().openRawResource(getResources().getIdentifier("d9_bus_horn", "raw", getPackageName())));
                        //      String uri = String.valueOf(getResources().getIdentifier(path + "/facebook_ringtone_pop.m4a", "raw", getPackageName()));
                        File file = null;
                        try {
                            file = new File(path);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
//                        file = new File(uri);
                        if (!result.getStatus().isSuccess()) {
                            Log.i("", "Failed to create new contents.");
                            return;
                        }
                        Log.i("", "Connection successful, creating new contents...");
                        // Otherwise, we can write our data to the new contents.
                        // Get an output stream for the contents.
                        OutputStream outputStream = result.getDriveContents()
                                .getOutputStream();
                        FileInputStream fis;
                        try {
                            fis = new FileInputStream(file.getPath());
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            byte[] buf = new byte[1024];
                            int n;
                            while (-1 != (n = fis.read(buf)))
                                baos.write(buf, 0, n);
                            byte[] photoBytes = baos.toByteArray();
                            outputStream.write(photoBytes);

                            outputStream.close();
                            outputStream = null;
                            fis.close();
                            fis = null;

                        } catch (FileNotFoundException e) {
                            Log.w("", "FileNotFoundException: " + e.getMessage());
                        } catch (IOException e1) {
                            Log.w("", "Unable to write file contents." + e1.getMessage());
                        }

                        String title = file.getName();
                        MetadataChangeSet metadataChangeSet = new MetadataChangeSet.Builder()
                                .setMimeType("audio*//*").setTitle(title).build();

//                        if (mime.equals(MIME_PHOTO)) {
//                            if (VERBOSE)
//                                Log.i(TAG, "Creating new photo on Drive (" + title
//                                        + ")");
//                            Drive.DriveApi.getFolder(mDriveClient,
//                                    mPicFolderDriveId).createFile(mDriveClient,
//                                    metadataChangeSet,
//                                    result.getDriveContents());
//                        } else
//                        if (mime.equals(MIME_VIDEO)) {
                        Log.i("", "Creating new video on Drive (" + title
                                + ")");
                        Drive.DriveApi.getRootFolder(mGoogleApiClient).createFile(mGoogleApiClient,
                                metadataChangeSet,
                                result.getDriveContents());
//                        }

//                        if (file.delete()) {
//                            if (VERBOSE)
//                                Log.d(TAG, "Deleted " + file.getName() + " from sdcard");
//                        } else {
//                            Log.w(TAG, "Failed to delete " + file.getName() + " from sdcard");
//                        }
                    }
                });
    }*/



}
