package example.com.callrecorder;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import example.com.callrecorder.database.DatabaseHelper;

public class Editnotes_activity extends AppCompatActivity {

    public Integer callerId;
    EditText txt_subject, txt_addnotes;
    Button btn_save;
    Toolbar toolbar;
    DatabaseHelper databaseHelper;
    String notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_notes);
        Intent i = getIntent();
        callerId = i.getIntExtra("callerId", 0);
//        notes = i.getStringExtra("userNotes");
//        Log.e("zahidd", "" + notes);
//        if (notes != null) {
//            txt_addnotes.setText(notes);
//        }
        databaseHelper = new DatabaseHelper(Editnotes_activity.this);

        findViewById();
        bindListener();
        Toolbar();


        String notess = databaseHelper.getContactNotes(callerId);
        String subject = databaseHelper.getContactSubject(callerId);
        if(notess !=  null)
        {
            txt_addnotes.setText(notess);
        }
        if(subject != null){
            txt_subject.setText(subject);
        }
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.UpdateNotes(txt_addnotes.getText().toString(), callerId,txt_subject.getText().toString());
                Toast.makeText(Editnotes_activity.this, ""+R.string.added, Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
    public void Toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_notes);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_name);
        tvCatTitle.setText(getResources().getString(R.string.Notes));
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void bindListener() {
    }

    private void findViewById() {
        txt_subject = (EditText) findViewById(R.id.txt_subject);
        txt_addnotes = (EditText) findViewById(R.id.txt_addnotes);
        btn_save = (Button) findViewById(R.id.btn_save);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }
}
