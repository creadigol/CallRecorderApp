package example.com.callrecorder.Fragment;

/**
 * Created by ADMIN on 17-Oct-16.
 */


import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.timehop.stickyheadersrecyclerview.StickyRecyclerHeadersDecoration;

import java.util.ArrayList;
import java.util.WeakHashMap;

import example.com.callrecorder.Adapter.MyTagHeaderAdapter;
import example.com.callrecorder.MainActivity;
import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.R;
import example.com.callrecorder.database.DatabaseHelper;

public class TwoFragment extends Fragment  {
    private SwipeRefreshLayout refreshLayout;
    private boolean fadeHeader = true;
    private RecyclerView mListView;
    MyTagHeaderAdapter adapter;
    ArrayList<CallRecorderModel> callRecorderModels;
    DatabaseHelper db;
    WeakHashMap<View,Integer> mOriginalViewHeightPool = new WeakHashMap<View, Integer>();
    RecyclerView recyclerView;
    public TwoFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);


    }



    @Override
    public void onResume() {
        super.onResume();
//        setAdapter();

        if(MainActivity.SaveFlag == true) {
            MainActivity.SaveFlag = false;
//    Intent intent = new Intent(getActivity(),MainActivity.class);
//    getActivity().finish();
//    startActivity(intent);
            Fragment frg = TwoFragment.this;
//        frg = getFragmentManager().findFragmentByTag("INBOX");
            final FragmentTransaction ft = getFragmentManager().beginTransaction();
            ft.detach(frg);
            ft.attach(frg);
            ft.commit();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_two, container, false);
        // Inflate the layout for this fragment

        refreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.refresh_layout);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refreshLayout.setRefreshing(false);

                    }
                }, 1000);
            }
        });
        db = new DatabaseHelper(getActivity());
        recyclerView = (RecyclerView) view.findViewById(R.id.list);
//        adapter = new MyTagHeaderAdapter(getContext());
//        callRecorderModels = new ArrayList<>();
//        callRecorderModels = db.getAllCallRecordDetail();
        setAdapter();


        return view;
    }

    public  void setAdapter(){
        //recyclerView = (RecyclerView) view.findViewById(R.id.list);
        adapter = new MyTagHeaderAdapter(getContext());
        callRecorderModels = new ArrayList<>();
        callRecorderModels = db.getSavedItem();


        for(int i=0;i<callRecorderModels.size();i++)
        {
            Log.e("name",""+callRecorderModels.get(i).getCallername());
            Log.e("number",""+callRecorderModels.get(i).getCallernumber());
            Log.e("time",""+callRecorderModels.get(i).getCallingtime());
        }

        if(callRecorderModels.size()>0) {
            recyclerView.setVisibility(View.VISIBLE);

//            if(adapter==null) {

            LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity().getBaseContext());
            recyclerView.setLayoutManager(layoutManager);


            //adapter.add("Animals below!");
            adapter.addAll(callRecorderModels);
            recyclerView.setAdapter(adapter);

            // Add the sticky headers decoration
            final StickyRecyclerHeadersDecoration headersDecor = new StickyRecyclerHeadersDecoration(adapter);
            recyclerView.addItemDecoration(headersDecor);

            // Add decoration for dividers between list items
//        recyclerView.addItemDecoration(new DividerDecoration(getActivity().getBaseContext()));

            adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
                @Override
                public void onChanged() {
                    headersDecor.invalidateHeaders();
                }
            });
//            }else{
//                adapter.modifyDataSet(callRecorderModels);
//            }

            //recyclerView.setOnClickListener();
        }
    }


}