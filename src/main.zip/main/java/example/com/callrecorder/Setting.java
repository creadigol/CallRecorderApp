package example.com.callrecorder;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.nononsenseapps.filepicker.FilePickerActivity;

import java.util.ArrayList;

import example.com.callrecorder.Utils.PreferenceSettings;

import static example.com.callrecorder.Fragment.OneFragment.context;
//import example.com.callrecorder.views.DirChooserFragmentSample;

public class Setting extends AppCompatActivity implements View.OnClickListener {
    Switch switchrecord, externelplayer;
    LinearLayout ll_recording, ll_filter, ll_notification, ll_cloud, ll_save, storagePath, resetPath;
    RadioButton radioButton, rb_ask, rb_save, rb_notsave;
    String st_radiobtn;
    TextView version_no, tv_Path;
    PreferenceSettings pref;
    String recor = "true";
    String recor2 = "false";
    ImageView off_switch;

    @Override
    protected void onResume() {
        tv_Path.setText(pref.getRecordingPath().toString());
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        pref = new PreferenceSettings(Setting.this);
//        switchrecord = (Switch) findViewById(R.id.mySwitch);
        externelplayer = (Switch) findViewById(R.id.externelplayer);
        inittoolbar();
//        mpPreference= CallRecorderApplication.getInstance().getPreferenceSettings();

        version_no = (TextView) findViewById(R.id.version_no);
        off_switch = (ImageView) findViewById(R.id.iv_on);
        tv_Path = (TextView) findViewById(R.id.tv_Path);
        ll_recording = (LinearLayout) findViewById(R.id.ll_recording);
        ll_filter = (LinearLayout) findViewById(R.id.ll_filter);
        ll_notification = (LinearLayout) findViewById(R.id.ll_notification);
        ll_cloud = (LinearLayout) findViewById(R.id.ll_cloud);
        storagePath = (LinearLayout) findViewById(R.id.storagePath);
        resetPath = (LinearLayout) findViewById(R.id.resetPath);
        ll_save = (LinearLayout) findViewById(R.id.ll_save);
        ll_recording.setOnClickListener(this);
        ll_filter.setOnClickListener(this);
        ll_notification.setOnClickListener(this);
        ll_cloud.setOnClickListener(this);
        ll_save.setOnClickListener(this);
        storagePath.setOnClickListener(this);
        resetPath.setOnClickListener(this);
        off_switch.setOnClickListener(this);
        if (pref.getAUTOSAVE_RECORDING()) {
            Log.e("autorecoding", "" + pref.getAUTOSAVE_RECORDING());
            off_switch.setImageResource(R.drawable.on_switch);
        } else if (pref.getAUTOSAVE_RECORDING() == false) {
            Log.e("autorecoding", "" + pref.getAUTOSAVE_RECORDING());
            off_switch.setImageResource(R.drawable.off_switch);
        }

        tv_Path.setText(pref.getRecordingPath().toString());
        // switchrecord.setChecked(true);
//        switchrecord.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
//        {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if(isChecked)
//                {
//                    pref.setAUTOSAVE_RECORDING(true);
//                    Log.e("Record calls" ,""+ pref.getAUTOSAVE_RECORDING());
//                }
//                else
//                {
//                    pref.setAUTOSAVE_RECORDING(false);
//                    Log.e("Record calls",""+ pref.getAUTOSAVE_RECORDING());
//                }
//            }
//        });

        externelplayer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {


                if (isChecked) {
                    pref.setSettingExternalPlayer(recor);
                    // pref.getSettingExternalPlayer();
                } else {
                    pref.setSettingExternalPlayer(recor2);
                    //pref.getSettingExternalPlayer();
                }
            }
        });

        PackageInfo pInfo = null;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        version_no.setText(pInfo.versionName);
    }

    public void inittoolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(getResources().getString(R.string.action_settings));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }

    private void dialogsave() {
        final Dialog dialog = new Dialog(Setting.this);
        dialog.setContentView(R.layout.dialog_saverecording);
        dialog.setTitle(getResources().getString(R.string.SaveRecording));

        RadioGroup rg_group = (RadioGroup) dialog.findViewById(R.id.rginbox);
        rb_ask = (RadioButton) dialog.findViewById(R.id.rb_ask);
        rb_save = (RadioButton) dialog.findViewById(R.id.rb_save);
        rb_notsave = (RadioButton) dialog.findViewById(R.id.rb_notsave);
        TextView tv_cencal = (TextView) dialog.findViewById(R.id.tv_cancelsave);
        Savedata();
        rg_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                @Override
                                                public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                    radioButton = (RadioButton) dialog.findViewById(checkedId);
                                                    st_radiobtn = (String) radioButton.getText();
                                                    pref.setSaveRecording(st_radiobtn);
                                                    dialog.dismiss();
                                                }
                                            }
        );
        tv_cencal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.show();
    }

    public void dialogBox() {
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage(getResources().getString(R.string.Turnoffrecording));
        alertDialogBuilder.setPositiveButton(getResources().getString(R.string.YES),
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        pref.setAUTOSAVE_RECORDING(false);
                        off_switch.setImageResource(R.drawable.off_switch);
                    }
                });

        alertDialogBuilder.setNegativeButton(getResources().getString(R.string.CANCEL),
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    public void Savedata() {
        try {
            if (pref.getSaveRecording() != null) {
                if (pref.getSaveRecording().equalsIgnoreCase(getResources().getString(R.string.Askwhattodo))) {
                    rb_ask.setChecked(true);
                } else if (pref.getSaveRecording().equalsIgnoreCase(getResources().getString(R.string.Savetherecording))) {
                    rb_save.setChecked(true);
                } else if (pref.getSaveRecording().equalsIgnoreCase(getResources().getString(R.string.Dontsaverecording))) {
                    rb_notsave.setChecked(true);
                }
            }
        } catch (Exception ex) {
            Log.e("error", "" + ex);
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_on:
                if (pref.getAUTOSAVE_RECORDING()) {
                    dialogBox();
                } else if (pref.getAUTOSAVE_RECORDING() == false) {
                    pref.setAUTOSAVE_RECORDING(true);
                    off_switch.setImageResource(R.drawable.on_switch);
                }
                break;
            case R.id.ll_recording:
                Intent i = new Intent(Setting.this, Recording.class);
                startActivity(i);
                break;
            case R.id.ll_filter:
                Intent filter = new Intent(Setting.this, Filter.class);
                startActivity(filter);
                pref.getSettingRecordCalls();
                System.out.println("Record calls" + pref.getSettingRecordCalls());
                Log.e("RECORing", pref.getSettingRecordCalls());
                break;
            case R.id.ll_notification:
                Intent noti = new Intent(Setting.this, Notification_activity.class);
                startActivity(noti);
                break;
            case R.id.ll_cloud:
                Intent cloud = new Intent(Setting.this, CloudAccount.class);
                startActivity(cloud);
                break;
            case R.id.ll_save:
                dialogsave();
                break;

            case R.id.storagePath:
//                Intent path=new Intent(Setting.this,DirectoryPicker.class);
//                startActivity(path);
                // This always works
                Intent ii = new Intent(context, FilePickerActivity.class);
                // This works if you defined the intent filter
                // Intent i = new Intent(Intent.ACTION_GET_CONTENT);

                // Set these depending on your use case. These are the defaults.
                ii.putExtra(FilePickerActivity.EXTRA_ALLOW_MULTIPLE, false);
                ii.putExtra(FilePickerActivity.EXTRA_ALLOW_CREATE_DIR, false);
                ii.putExtra(DirectoryPicker.SHOW_HIDDEN, false);
                ii.putExtra(FilePickerActivity.EXTRA_MODE, FilePickerActivity.MODE_DIR);

                // Configure initial directory by specifying a String.
                // You could specify a String like "/storage/emulated/0/", but that can
                // dangerous. Always use Android's API calls to get paths to the SD-card or
                // internal memory.
                ii.putExtra(FilePickerActivity.EXTRA_START_PATH, Environment.getExternalStorageDirectory().getPath());

                startActivityForResult(ii, 2000);
                break;
            case R.id.resetPath:
                pref.setRecordingPath("/sdcard/callrecorder");
                tv_Path.setText("/sdcard/callrecorder");
                break;
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 2000 && resultCode == Activity.RESULT_OK) {
            if (data.getBooleanExtra(FilePickerActivity.EXTRA_ALLOW_MULTIPLE, false)) {
                // For JellyBean and above
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    ClipData clip = data.getClipData();

                    if (clip != null) {
                        for (int i = 0; i < clip.getItemCount(); i++) {
                            Uri uri = clip.getItemAt(i).getUri();
                            Toast.makeText(this, ""+uri, Toast.LENGTH_SHORT).show();
                            // Do something with the URI
                            pref.setRecordingPath(String.valueOf(uri).substring(8));
                        }
                    }
                    // For Ice Cream Sandwich
                } else {
                    ArrayList<String> paths = data.getStringArrayListExtra
                            (FilePickerActivity.EXTRA_PATHS);

                    if (paths != null) {
                        for (String path : paths) {
                            Uri uri = Uri.parse(path);
                            Toast.makeText(this, ""+uri, Toast.LENGTH_SHORT).show();
                            pref.setRecordingPath(String.valueOf(uri).substring(8));

                            // Do something with the URI
                        }
                    }
                }

            } else {
                Uri uri = data.getData();
                Toast.makeText(this, ""+uri, Toast.LENGTH_SHORT).show();
                pref.setRecordingPath(String.valueOf(uri).substring(8));

                // Do something with the URI
            }
        }

    }
}
