package example.com.callrecorder.Model;

import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ADMIN on 19-Oct-16.
 */

public class IgnorecontactModel {

    int callerid;

    public int getCallerid() {
        return callerid;
    }

    public void setCallerid(int callerid) {
        this.callerid = callerid;
    }

    public String getContactname() {
        return contactname;
    }

    public void setContactname(String contactname) {
        this.contactname = contactname;
    }

    public String getContactnumber() {
        return contactnumber;
    }

    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }

    String contactname;
    String contactnumber;
}
