package example.com.callrecorder.Model;

import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ADMIN on 19-Oct-16.
 */

public class CallRecorderModel {

    int callerid;
    String callername;
    String callerimage;


    //    long callernumber;
    String callernumber;
    String callingdate;
    String delete;

    public String getCallDuration() {
        return callDuration;
    }

    public void setCallDuration(String callDuration) {
        this.callDuration = callDuration;
    }

    String callDuration;

    public String getUpload() {
        return upload;
    }

    public void setUpload(String upload) {
        this.upload = upload;
    }

    String upload;

    public String getDelete() {
        return delete;
    }

    public void setDelete(String delete) {
        this.delete = delete;
    }

    public String getCallernumber() {
        return callernumber;
    }

    public void setCallernumber(String callernumber) {

        if(callernumber!=null&&callernumber.trim().length()>0)
        {
            this.callernumber = callernumber;
        }else
        {
            this.callernumber= String.valueOf(0);
        }
    }

    String callingtime;
    String type;
    String usernotes;
    String saved;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    String subject;

    public String getSaved() {
        return saved;
    }

    public void setSaved(String saved) {
        this.saved = saved;
    }

    public String getCallerday() {
        return callerday;
    }

    public void setCallerday(String callerday) {
        this.callerday = callerday;
    }

    public void setHeaderDate(String headerDate) {
        this.headerDate = headerDate;
    }

    String callerday;

    public String getRecordingpath() {
        return recordingpath;
    }

    public void setRecordingpath(String recordingpath) {
        this.recordingpath = recordingpath;
    }

    String recordingpath;

    public int getCallerid() {
        return callerid;
    }

    public void setCallerid(int callerid) {
        this.callerid = callerid;
    }

    public String getCallername() {
        return callername;
    }

    public void setCallername(String callername) {
        this.callername = callername;
    }

    public String getCallerimage() {
        return callerimage;
    }

    public void setCallerimage(String callerimage) {
        this.callerimage = callerimage;
    }


    public String getCallingdate() {
        return callingdate;
    }

    public void setCallingdate(String callingdate) {
        this.callingdate = callingdate;
    }

    public String getCallingtime() {
        return callingtime;
    }

    public void setCallingtime(String callingtime) {
        this.callingtime = callingtime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUsernotes() {
        return usernotes;
    }

    public void setUsernotes(String usernotes) {
        this.usernotes = usernotes;
    }

    long date;
    String headerDate, transactionDate;

    public long getDate() {
        return date;
    }

    private void setDate(long dateMilliSeconds) {

        try {
            DateFormat formatter = new SimpleDateFormat("dd MMM yyyy");
            Date date_temp = formatter.parse(getFormatedDate(dateMilliSeconds, "dd MMM yyyy"));
            this.date = date_temp.getTime();
        } catch (Exception e) {
            this.date = 0;
        }
        Log.e("setDate", "this.date:" + this.date);
    }

    public String getHeaderDate() {
        return headerDate;
    }

    public void setHeaderDate(long dateMilliSeconds) {
        try {
//            this.headerDate = getFormatedDate(dateMilliSeconds, "dd MMM");
            this.headerDate = getFormatedDate(dateMilliSeconds, "dd-M-yyyy");
        } catch (Exception e) {
            this.headerDate = null;
        }
        Log.e("setHeaderDate", "this.headerDate:" + this.headerDate);
        setDate(dateMilliSeconds);
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(String transactionDate) {

        Log.e("setTransactionDate", "input transactionDate:" + transactionDate);

        long dateMilliSeconds = 0;
        try {
            dateMilliSeconds = Long.parseLong(transactionDate);
            Log.e("setTransactionDate", "input dateMilliSeconds:" + dateMilliSeconds);
            //dateMilliSeconds = dateMilliSeconds * 100;

            this.transactionDate = getFormatedDate(dateMilliSeconds, "dd MMM yyyy hh:mm aaa");

        } catch (Exception e) {
            this.transactionDate = null;
        }
        Log.e("setTransactionDate", "this.transactionDate:" + this.transactionDate);
        setHeaderDate(dateMilliSeconds);
    }

    public static String getFormatedDate(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        DateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        //String date = formatter.format(calendar.getTime());
        return formatter.format(calendar.getTime());

//        try {
//            return formatter.parse(date);
//        } catch (ParseException e) {
//            return null;
//        }
    }
}
