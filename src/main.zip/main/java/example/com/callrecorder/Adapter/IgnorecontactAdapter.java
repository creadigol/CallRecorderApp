package example.com.callrecorder.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.Model.IgnorecontactModel;
import example.com.callrecorder.R;

public class IgnorecontactAdapter extends RecyclerView.Adapter<ViewHolder> {


	private static Context context;
	ArrayList<IgnorecontactModel> ignorecontactModels;
	OnClickListener onClickListener;

	public IgnorecontactAdapter(Context context,ArrayList<IgnorecontactModel> ignorecontactModels,OnClickListener onClickListener) {
		// TODO Auto-generated constructor stub
		this.context = context;
		this.ignorecontactModels=ignorecontactModels;
		this.onClickListener=onClickListener;
	}

	@Override
	public int getItemCount() {
		// TODO Auto-generated method stub
		return ignorecontactModels.size();
//		return 4;
	}

	@Override
	public void onBindViewHolder(ViewHolder viewHolder,
			final int position) {
		// TODO Auto-generated method stub
		final TextFeedViewHolder holder = (TextFeedViewHolder) viewHolder;

		holder.name.setText(ignorecontactModels.get(position).getContactname());
		holder.number.setText(ignorecontactModels.get(position).getContactnumber());
//		Toast.makeText(context, "name"+ignorecontactModels.get(position).getContactname(), Toast.LENGTH_SHORT).show();
//		Toast.makeText(context, "number"+ignorecontactModels.get(position).getContactnumber(), Toast.LENGTH_SHORT).show();

		holder.linearLayout.setTag(position);
		holder.linearLayout.setOnClickListener(onClickListener);
	}

	@Override
	public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
		// TODO Auto-generated method stub

		final View view = LayoutInflater.from(context).inflate(
				R.layout.custome_ignorecontact_layout, parent, false);

		final TextFeedViewHolder textFeedViewHolder = new TextFeedViewHolder(
				view);

		return textFeedViewHolder;

	}

	public static class TextFeedViewHolder extends ViewHolder {
		TextView number,name;
		LinearLayout linearLayout;

		public TextFeedViewHolder(View view) {
			super(view);

			number = (TextView) view.findViewById(R.id.ignorenumber);
			name = (TextView) view.findViewById(R.id.ignorename);
			linearLayout=(LinearLayout)view.findViewById(R.id.ll_ignore);
		}
	}
}
