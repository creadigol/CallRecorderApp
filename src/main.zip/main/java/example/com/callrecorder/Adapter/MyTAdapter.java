package example.com.callrecorder.Adapter;

import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import example.com.callrecorder.Model.CallRecorderModel;

/**
 * Created by Vj on 8/2/2016.
 */

public abstract class MyTAdapter <VH extends RecyclerView.ViewHolder>
            extends RecyclerView.Adapter<VH> {
        private ArrayList<CallRecorderModel> items = new ArrayList<CallRecorderModel>();

        public MyTAdapter() {
            setHasStableIds(true);
        }

        public void add(CallRecorderModel object) {
            items.add(object);
            notifyDataSetChanged();
        }

        public void add(int index, CallRecorderModel object) {
            items.add(index, object);
            notifyDataSetChanged();
        }

        public void addAll(Collection<? extends CallRecorderModel> collection) {
            if (collection != null) {
                items.addAll(collection);
                notifyDataSetChanged();
            }
        }

        public void replaceAll(Collection<? extends CallRecorderModel> collection) {
            if (collection != null) {
                items = new ArrayList<CallRecorderModel>();
                items.addAll(collection);
                notifyDataSetChanged();
            }
        }

        public void addAll(CallRecorderModel... items) {
            addAll(Arrays.asList(items));
        }

        public void clear() {
            items.clear();
            notifyDataSetChanged();
        }

        public void remove(CallRecorderModel object) {
            items.remove(object);
            notifyDataSetChanged();
        }

        public CallRecorderModel getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return getItem(position).hashCode();
        }

        @Override
        public int getItemCount() {
            return items.size();
        }
    }
