package example.com.callrecorder.callrecordersdata;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.ContactsContract;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.model.PointOfInterest;
import com.google.android.gms.plus.model.people.Person;

import java.text.SimpleDateFormat;
import java.util.Date;

public class PhoneListener extends PhoneStateListener {
    static String contactName;
    String outgoinNumber;
    String ImageUrl, name;
    private Context context;

    public PhoneListener(Context c, String outgoinNumber) {
        Log.i("CallRecorder", "PhoneListener constructor");
        context = c;
        this.outgoinNumber = outgoinNumber;
    }

    public void onCallStateChanged(int state, String incomingNumber) {
              Log.d("CallRecorder", "PhoneListener::onCallStateChanged state:" + state + " incomingNumber:" + incomingNumber + "outgoinNumber" + outgoinNumber);
        try {
            if (incomingNumber != null) {

                getImage(incomingNumber);
                getName(incomingNumber);
            } else if (outgoinNumber != null) {
                getImage(outgoinNumber);
                getName(outgoinNumber);
            }
        } catch (Exception e) {
        }
//        getContactName(context,incomingNumber);
//        getContactName(incomingNumber);
        switch (state) {
            case TelephonyManager.CALL_STATE_IDLE:
                Log.d("CallRecorder", "CALL_STATE_IDLE, stoping recording");

                Boolean stopped = context.stopService(new Intent(context, RecordService.class));


                Log.i("CallRecorder", "stopService for RecordService returned " + stopped);
                break;
            case TelephonyManager.CALL_STATE_RINGING:
                Log.d("CallRecorder", "CALL_STATE_RINGING");
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                Log.d("CallRecorder", "CALL_STATE_OFFHOOK starting recording");

                Intent callIntent = new Intent(context, RecordService.class);
                callIntent.putExtra("incomingnumberr", incomingNumber);
                callIntent.putExtra("outgoingnumber", outgoinNumber);
                Log.e("phonelistener", "zzz" + incomingNumber + "out" + incomingNumber);
                callIntent.putExtra("ImageUrl", ImageUrl);
                callIntent.putExtra("contactName", name);
                ComponentName name = context.startService(callIntent);

                if (null == name) {
                    Log.e("CallRecorder", "startService for RecordService returned null ComponentName");
                } else {
                    Log.i("CallRecorder", "startService returned " + name.flattenToString());
                }
                outgoinNumber = null;
                incomingNumber = null;

                break;
        }
    }

    public void getImage(String mobileNumber) {
        String imnage;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            imnage = phonesCursor.getString(0);
//        imageView=(ImageView)findViewById(R.id.image);
            try {
                ImageUrl = String.valueOf(Uri.parse(imnage));
                Log.e("phonelistener", "image path" + Uri.parse(imnage));
//            imageView.setImageURI(Uri.parse(imnage));
                Log.e("detail", "==============" + imnage);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            // displayName = phonesCursor.getString(0); // this is the contact name
        } else {
            Log.e("no contact ", "============");
        }
    }

    public void getName(String mobileNumber) {
        String imnage;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            imnage = phonesCursor.getString(0);

            try {
                name = String.valueOf(Uri.parse(imnage));
                Log.e("phonelistener", "contact name" + Uri.parse(name));
//            imageView.setImageURI(Uri.parse(imnage));
                Log.e("detail", "==============" + imnage);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            // displayName = phonesCursor.getString(0); // this is the contact name
        } else {
            Log.e("no contact ", "============");
        }
    }

//    private Cursor getAllCallLogs(ContentResolver cr) {
//        // reading all data in descending order according to DATE
//        String strOrder = android.provider.CallLog.Calls.DATE + " DESC";
//        Uri callUri = Uri.parse("content://call_log/calls");
//        Cursor cur = cr.query(callUri, null, null, null, strOrder);
//        // loop through cursor
//        while (cur.moveToNext()) {
//            String callNumber = cur.getString(cur
//                    .getColumnIndex(android.provider.CallLog.Calls.NUMBER));
//            String callName = cur
//                    .getString(cur
//                            .getColumnIndex(android.provider.CallLog.Calls.CACHED_NAME));
//            String callDate = cur.getString(cur
//                    .getColumnIndex(android.provider.CallLog.Calls.DATE));
//            SimpleDateFormat formatter = new SimpleDateFormat(
//                    "dd-MMM-yyyy HH:mm");
//            String dateString = formatter.format(new Date(Long
//                    .parseLong(callDate)));
//            String callType = cur.getString(cur
//                    .getColumnIndex(android.provider.CallLog.Calls.TYPE));
//            String isCallNew = cur.getString(cur
//                    .getColumnIndex(android.provider.CallLog.Calls.NEW));
//            String duration = cur.getString(cur
//                    .getColumnIndex(android.provider.CallLog.Calls.DURATION));
//            Log.e("duration","phonelistner"+duration);
//            // process log data...
//        }
//        return cur;
//
//    }



//    public String getContactName(final String phoneNumber)
//    {
//        Uri uri;
//        String[] projection;
//        Uri mBaseUri = Contacts.Phones.CONTENT_FILTER_URL;
//        projection = new String[] { android.provider.Contacts.People.NAME };
//        try {
//            Class<?> c =Class.forName("android.provider.ContactsContract$PhoneLookup");
//            mBaseUri = (Uri) c.getField("CONTENT_FILTER_URI").get(mBaseUri);
//            projection = new String[] { "display_name" };
//        }
//        catch (Exception e) {
//        }
//
//
//        uri = Uri.withAppendedPath(mBaseUri, Uri.encode(phoneNumber));
//        Cursor cursor = context.getContentResolver().query(uri, projection, null, null, null);
//
//        String contactName = "";
//
//        if (cursor.moveToFirst())
//        {
//            contactName = cursor.getString(0);
//            Log.e("phonelistener", "contactName" + contactName);
//        }
//
//        cursor.close();
//        cursor = null;
//
//        return contactName;
//    }

//    public static String getContactName(Context context, String phoneNumber) {
//        ContentResolver cr = context.getContentResolver();
//        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
//        Cursor cursor = cr.query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
////        Cursor duration = cr.query(uri, new String[]{String.valueOf(CallLog.Calls.CONTENT_URI)}, null, null, null);
//        if (cursor == null) {
//            return null;
//        }
//        CallRecorderModel callRecorderModel = new CallRecorderModel();
//        if(cursor.moveToFirst()) {
//            contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
//            Log.e("contactName","="+contactName);
////            int dura = duration.getColumnIndex(CallLog.Calls.DURATION);
////            Log.e("contactName","="+dura);
//
//        }
//
//        if(cursor != null && !cursor.isClosed()) {
//            cursor.close();
//        }
//
//        return contactName;
//    }

}
