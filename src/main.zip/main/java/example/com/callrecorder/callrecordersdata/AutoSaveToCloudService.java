package example.com.callrecorder.callrecordersdata;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

import example.com.callrecorder.MainActivity;
import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.database.DatabaseHelper;


/**
 * Created by ADMIN on 22-Sep-16.
 */
public class AutoSaveToCloudService extends Service {
DatabaseHelper database;
    ArrayList<CallRecorderModel> callRecorderModels;
    public AutoSaveToCloudService() {
    }
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    @Override
    public void onCreate() {
//        Toast.makeText(AutoSaveToCloudService.this, "Service was Created", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStart(Intent intent, int startId) {
        // Perform your long running operations here.

        database = new DatabaseHelper(getBaseContext());
        callRecorderModels = new ArrayList<>();
      int size =  database.getautosaveToCloud().size();
        callRecorderModels =  database.getautosaveToCloud();

        for (int i=0;i<size;i++){
            MainActivity.saveFiletoDrive(callRecorderModels.get(i).getRecordingpath());
            database.UpdateCloudStatus(callRecorderModels.get(i).getCallerid(), "true");
            Log.e("myservice",""+callRecorderModels.get(i).getRecordingpath());
        }
//        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDestroy() {
//        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
    }



}