package example.com.callrecorder.callrecordersdata;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.plus.model.people.Person;

import java.util.Date;

import example.com.callrecorder.Utils.PreferenceSettings;

import static example.com.callrecorder.Fragment.OneFragment.context;

public class CallBroadcastReceiver extends BroadcastReceiver {
//    public static String numberToCall;
//    PreferenceSettings pref;
//    CallRecorderModel callRecorderModel = new CallRecorderModel();
//    Boolean test = false;
//
//    public void onReceive(final Context context, final Intent intent) {

//        pref = new PreferenceSettings(context);
//        int delayIncoming = Integer.parseInt(pref.getDelayIncoming());
//        int delayOutgoing = Integer.parseInt(pref.getDelayOutgoing());
////        if(test == false)
////        setAlarm(context);
//
//        final Handler handler = new Handler();
//        final Handler handler2 = new Handler();
////
////        Log.d("CallRecorder", "CallBroadcastReceiver::onReceive got Intent: " + intent.toString());
////        if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
////            handler2.postDelayed(new Runnable() {
////                @Override
////                public void run() {
////                    numberToCall = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
////                    callRecorderModel.setCallernumber(numberToCall);
////                    Log.d("CallRecorder", "CallBroadcastReceiver intent has EXTRA_PHONE_NUMBER: " + numberToCall);
////
////                    Toast.makeText(context, "outgoing", Toast.LENGTH_SHORT).show();
////                }
////            }, delayOutgoing * 1000);
////        }else {
////
////            handler.postDelayed(new Runnable() {
////                @Override
////                public void run() {
////                    // Do something after 5s = 5000ms
////
////                    PhoneListener phoneListener = new PhoneListener(context, numberToCall);
////                    TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
////                    telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
////                    Log.d("PhoneStateReceiver::onReceive", "set PhoneStateListener");
////                    Toast.makeText(context, "innn", Toast.LENGTH_LONG).show();
////                }
////            }, delayIncoming * 1000);
////        }
//
//
//
//        /*
//        * old
//        *
//        * */
////        if (test == true) {
//        Log.d("CallRecorder", "CallBroadcastReceiver::onReceive got Intent: " + intent.toString());
//        if (intent.getAction().equalsIgnoreCase(Intent.ACTION_NEW_OUTGOING_CALL)) {
//            numberToCall = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
//            callRecorderModel.setCallernumber(numberToCall);
//            test = true;
//            Log.d("CallRecorder", "CallBroadcastReceiver intent has EXTRA_PHONE_NUMBER: " + numberToCall);
//
////            Toast.makeText(context, "outgoing", Toast.LENGTH_SHORT).show();
//        }
//        if (test == true) {
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    // Do something after 5s = 5000ms
//
//                    PhoneListener phoneListener = new PhoneListener(context, numberToCall);
//                    TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//                    telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
//                    Log.d("PhoneStateReceiver::onReceive", "set PhoneStateListener");
//                    Toast.makeText(context, "innn", Toast.LENGTH_LONG).show();
//                }
//            }, delayIncoming * 10000);
//        } else if (test == false) {
//            handler.postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    // Do something after 5s = 5000ms
//
//                    PhoneListener phoneListener = new PhoneListener(context, numberToCall);
//                    TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
//                    telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
//                    Log.d("PhoneStateReceiver::onReceive", "set PhoneStateListener");
//                    Toast.makeText(context, "innn", Toast.LENGTH_LONG).show();
//                }
//            }, delayIncoming * 30000);
//        }
////                PhoneListener phoneListener = new PhoneListener(context, numberToCall);
////                TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
////                telephony.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
////                Log.d("PhoneStateReceiver::onReceive", "set PhoneStateListener");
//
////        if(intent.getAction().equalsIgnoreCase(Intent.ACTION_NEW_OUTGOING_CALL)){
////            Toast.makeText(context, "innnnnn", Toast.LENGTH_LONG).show();
////
////        }else if (intent.getAction().equalsIgnoreCase(Intent.ACTION_NEW_OUTGOING_CALL)) {
////
////
////            Toast.makeText(context, "outtttt", Toast.LENGTH_LONG).show();
////
////        }
//
//
////        }
////            Toast.makeText(context, "auto", Toast.LENGTH_SHORT).show();
//
//
//    }
//    /*public class ServiceReceiver extends BroadcastReceiver {
//
//        @Override
//        public void onReceive(final Context context, Intent intent) {
//            TelephonyManager telephony = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
//            telephony.listen(new PhoneStateListener(){
//                @Override
//                public void onCallStateChanged(int state, String incomingNumber) {
//                    super.onCallStateChanged(state, incomingNumber);
//                    System.out.println("incomingNumber : "+incomingNumber);
//                }
//            },PhoneStateListener.LISTEN_CALL_STATE);
//        }
//    }*/
//
//    public void setAlarm(Context context) {
//        test = true;
//        int i = Integer.parseInt(pref.getDelayOutgoing());
//        Intent intent = new Intent(context, CallBroadcastReceiver.class);
//        PendingIntent pendingIntent = PendingIntent.getBroadcast(
//                context, 234324243, intent, 0);
//        AlarmManager alarmManager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
//        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()
//                + (System.currentTimeMillis() + i * 1000), pendingIntent);
//        Toast.makeText(context, "Alarm set in " + i + " seconds", Toast.LENGTH_LONG).show();
//    }
//


    /*temp*/

    private static int lastState = TelephonyManager.CALL_STATE_IDLE;
    private static Date callStartTime;
    private static boolean isIncoming;
    private static String savedNumber;  //because the passed incoming is only valid in ringing
    String ImageUrl, name;
    PreferenceSettings pref = new PreferenceSettings(context);
    int incomingDelay,OutgoingDelay;
    @Override
    public void onReceive(Context context, Intent intent) {
incomingDelay = Integer.parseInt(pref.getDelayIncoming());
        OutgoingDelay = Integer.parseInt(pref.getDelayOutgoing());
        //We listen to two intents.  The new outgoing call only tells us of an outgoing call.  We use it to get the number.
        if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
            savedNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
        } else {
            String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
            String number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
            int state = 0;
            if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                state = TelephonyManager.CALL_STATE_IDLE;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                state = TelephonyManager.CALL_STATE_OFFHOOK;
            } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                state = TelephonyManager.CALL_STATE_RINGING;
            }


            onCallStateChanged(context, state, number);
        }
    }

    //Derived classes should override these to respond to specific events of interest
    protected void onIncomingCallStarted(final Context ctx, final String number, Date start) {

        if (number != null) {
            getImage(number);
            getName(number);
        }

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms

                Intent callIntent = new Intent(ctx, RecordService.class);
                callIntent.putExtra("incomingnumberr", number);
//                    callIntent.putExtra("outgoingnumber", savedNumber);
                callIntent.putExtra("ImageUrl", ImageUrl);
                callIntent.putExtra("contactName", name);
                context.startService(callIntent);
            }
        }, incomingDelay * 1000);


    }

    protected void onOutgoingCallStarted(final Context ctx, final String number, Date start) {

        if (number != null) {
            getImage(number);
            getName(number);
        }


        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Do something after 5s = 5000ms

                Intent callIntent = new Intent(ctx, RecordService.class);
                callIntent.putExtra("outgoingnumber", number);
//                    callIntent.putExtra("outgoingnumber", savedNumber);
                callIntent.putExtra("ImageUrl", ImageUrl);
                callIntent.putExtra("contactName", name);
                context.startService(callIntent);
            }
        }, OutgoingDelay * 1000);


    }

    protected void onIncomingCallEnded(Context ctx, String number, Date start, Date end) {
context.stopService(new Intent(context, RecordService.class));

    }

    protected void onOutgoingCallEnded(Context ctx, String number, Date start, Date end) {
        context.stopService(new Intent(context, RecordService.class));

    }

    protected void onMissedCall(Context ctx, String number, Date start) {
        context.stopService(new Intent(context, RecordService.class));

    }


    //Deals with actual events

    //Incoming call-  goes from IDLE to RINGING when it rings, to OFFHOOK when it's answered, to IDLE when its hung up
    //Outgoing call-  goes from IDLE to OFFHOOK when it dials out, to IDLE when hung up
    public void onCallStateChanged(Context context, int state, String number) {

        if (lastState == state) {
            context.stopService(new Intent(context, RecordService.class));

            //No change, debounce extras
            return;
        }
        switch (state) {
            case TelephonyManager.CALL_STATE_RINGING:
                isIncoming = true;
                callStartTime = new Date();
                savedNumber = number;
                onIncomingCallStarted(context, number, callStartTime);
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //Transition of ringing->offhook are pickups of incoming calls.  Nothing done on them
                if (lastState != TelephonyManager.CALL_STATE_RINGING) {
                    isIncoming = false;
                    callStartTime = new Date();
                    onOutgoingCallStarted(context, savedNumber, callStartTime);
                }
                break;
            case TelephonyManager.CALL_STATE_IDLE:
                //Went to idle-  this is the end of a call.  What type depends on previous state(s)
                if (lastState == TelephonyManager.CALL_STATE_RINGING) {
                    //Ring but no pickup-  a miss
                    onMissedCall(context, savedNumber, callStartTime);
                } else if (isIncoming) {
                    onIncomingCallEnded(context, savedNumber, callStartTime, new Date());

//                    Toast.makeText(context, "incomingz" + savedNumber, Toast.LENGTH_LONG).show();

                } else {
                    onOutgoingCallEnded(context, savedNumber, callStartTime, new Date());
//                    Toast.makeText(context, "outgoingz" + savedNumber, Toast.LENGTH_LONG).show();


                }
                break;
        }
        lastState = state;
    }

    public void getImage(String mobileNumber) {
        String imnage;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            imnage = phonesCursor.getString(0);
//        imageView=(ImageView)findViewById(R.id.image);
            try {
                ImageUrl = String.valueOf(Uri.parse(imnage));
                Log.e("phonelistener", "image path" + Uri.parse(imnage));
//            imageView.setImageURI(Uri.parse(imnage));
                Log.e("detail", "==============" + imnage);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            // displayName = phonesCursor.getString(0); // this is the contact name
        } else {
            Log.e("no contact ", "============");
        }
    }

    public void getName(String mobileNumber) {
        String imnage;
        Cursor phonesCursor = null;
        Person.Urls urls;
        // Get image from phone no
        try {
            Uri phoneUri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(mobileNumber));
            phonesCursor = context.getContentResolver().query(phoneUri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        if (phonesCursor != null && phonesCursor.moveToFirst()) {
            imnage = phonesCursor.getString(0);

            try {
                name = String.valueOf(Uri.parse(imnage));
                Log.e("phonelistener", "contact name" + Uri.parse(name));
//            imageView.setImageURI(Uri.parse(imnage));
                Log.e("detail", "==============" + imnage);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            // displayName = phonesCursor.getString(0); // this is the contact name
        } else {
            Log.e("no contact ", "============");
        }
    }
}
