package example.com.callrecorder.callrecordersdata;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import example.com.callrecorder.MainActivity;
import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.PopupActivity;
import example.com.callrecorder.R;
import example.com.callrecorder.Utils.PreferenceSettings;
import example.com.callrecorder.database.DatabaseHelper;

//import java.security.KeyPairGenerator;
//import java.security.KeyPair;
//import java.security.Key;


public class RecordService extends Service implements MediaRecorder.OnInfoListener, MediaRecorder.OnErrorListener {
    private static final String TAG = "CallRecorder";
    private static final int RECORDING_NOTIFICATION_ID = 1;
    //    public static final String DEFAULT_STORAGE_LOCATION = "/sdcard/callrecorder";
    public static String DEFAULT_STORAGE_LOCATION = "";
    static String a = null;
    static String tempName = null;
    static String Strincoming = null;
    static String Stroutgoing = null;
    static String incomingnumber, ImageUrl, contactName;
    String prefix;
    String recordingDate, dayoftheweek, time, callduration;
    DatabaseHelper db;
    String outgoingnumber;
    Context context;
    String tmp;
    String blue;
    PreferenceSettings pref;
    AudioManager audioManager;
    BluetoothAdapter adapter;
    String askWhatToDo;
    Boolean CheckName = false;
    String CuurentTime;
    RemoteViews contentView;
    private MediaRecorder recorder = null;
    private boolean isRecording = false;
    private File recording = null;
    private NotificationCompat.Builder builder;
    private Uri uriContact;
    /*
    private static void test() throws java.security.NoSuchAlgorithmException
    {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.genKeyPair();
        Key publicKey = kp.getPublic();
        Key privateKey = kp.getPrivate();
    }
    */
    private String contactID;

    private File makeOutputFile(SharedPreferences prefs) {
        File dir = new File(DEFAULT_STORAGE_LOCATION);

        // test dir for existence and writeability
        if (!dir.exists()) {
            try {
                dir.mkdirs();
            } catch (Exception e) {
                Log.e("CallRecorder", "RecordService::makeOutputFile unable to create directory " + dir + ": " + e);
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder was unable to create the directory " + dir + " to store recordings: " + e, Toast.LENGTH_LONG);
                t.show();
                return null;
            }
        } else {
            if (!dir.canWrite()) {
                Log.e(TAG, "RecordService::makeOutputFile does not have write permission for directory: " + dir);
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder does not have write permission for the directory directory " + dir + " to store recordings", Toast.LENGTH_LONG);
                t.show();
                return null;
            }
        }

        // test size

        // create filename based on call data
        //String prefix = "call";
        SimpleDateFormat sdf = new SimpleDateFormat("dd");
        prefix = sdf.format(new Date());
        recordingDate = sdf.format(new Date());

//        SimpleDateFormat day = new SimpleDateFormat("EEEE");
//        Date d = new Date();
//        dayoftheweek= day.format(d);
//

        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        dayoftheweek = dayFormat.format(calendar.getTime());
        Log.e("day", "" + dayoftheweek);

//        CallRecorderModel callRecorderModel = new CallRecorderModel();
//        callRecorderModel.setCallername("Shaikh Ashfaq");
//        callRecorderModel.setCallerimage("");
////        callRecorderModel.setCallerday(dayoftheweek);
////        callRecorderModel.setCallernumber(4444);
//        callRecorderModel.setCallingdate(recordingDate);
//        callRecorderModel.setCallingtime(dayoftheweek);
//        callRecorderModel.setType("incoming");
//        callRecorderModel.setRecordingpath(String.valueOf(recording));
//
//        db.insertCallRecorder(callRecorderModel);
        // add info to file name about what audio channel we were recording
//        int audiosource = Integer.parseInt(prefs.getString(Preferences.PREF_AUDIO_SOURCE, "1"));
        int audiosource = 3;
        prefix += "-channel" + audiosource + "-";

        // create suffix based on format
        String suffix = "";
//        int audioformat = Integer.parseInt(prefs.getString(Preferences.PREF_AUDIO_FORMAT, "1"));
        int formate = Integer.parseInt(pref.getAudioFormat());
        int audioformat = formate;
        switch (audioformat) {
            case MediaRecorder.OutputFormat.THREE_GPP:
                suffix = ".3gpp";
                break;
            case MediaRecorder.OutputFormat.MPEG_4:
                suffix = ".mp4";
                break;
            case MediaRecorder.OutputFormat.RAW_AMR:
                suffix = ".amr";
                break;
            case 4:
                suffix = ".mp3";
                break;
            case 5:
                suffix = ".flac";
                break;
            case 6:
                suffix = ".wav";
                break;
        }

        try {
            return File.createTempFile(prefix, suffix, dir);
        } catch (IOException e) {
            Log.e("CallRecorder", "RecordService::makeOutputFile unable to create temp file in " + dir + ": " + e);
//            Toast t =
            Toast.makeText(getApplicationContext(), "CallRecorder was unable to create temp file in " + dir + ": " + e, Toast.LENGTH_LONG);
//            t.show();
            return null;
        }
    }

    public void onCreate() {
        super.onCreate();

        recorder = new MediaRecorder();
        db = new DatabaseHelper(getApplicationContext());
        pref = new PreferenceSettings(RecordService.this);
        // DEFAULT_STORAGE_LOCATION = pref.getRecordingPath() + "/callrecorder";
        DEFAULT_STORAGE_LOCATION = pref.getRecordingPath();
        Log.i("CallRecorder", "onCreate created MediaRecorder object");
        tmp = pref.getRecordingSpeaker();
        askWhatToDo = pref.getSaveRecording();

        System.out.println("Prefrence temp value : " + tmp);
        if (tmp.equals("true")) {
            System.out.println("Prefrence  value : " + tmp);
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audioManager.setMode(AudioManager.MODE_IN_CALL);
            //    audioManager.setMode(AudioManager.MODE_NORMAL);
            audioManager.setSpeakerphoneOn(true);

            // Toast.makeText(Context(), "Hiiiiiiiiiiiiiiiii", Toast.LENGTH_SHORT).show();
        } else {
            audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audioManager.setMode(AudioManager.MODE_IN_CALL);
            //    audioManager.setMode(AudioManager.MODE_NORMAL);
            audioManager.setSpeakerphoneOn(false);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////
        adapter = BluetoothAdapter.getDefaultAdapter();
        BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
        blue = pref.getRecordingBluetooth();
        System.out.println("Prefrence  value bluetooth: " + blue);
        if (bluetooth.isEnabled()) {
            if (blue.equals("true")) {
                recorder.release();

            }
        }
//        else{
//
//        }


    }

    public void onStart(Intent intent, int startId) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        prefix = sdf.format(new Date());
        recordingDate = sdf.format(new Date());

        try {
            incomingnumber = intent.getStringExtra("incomingnumberr");
            outgoingnumber = intent.getStringExtra("outgoingnumber");

            Log.e("RecordService", intent.getStringExtra("incomingnumberr") + "test" + intent.getStringExtra("outgoingnumber"));
            ImageUrl = intent.getStringExtra("ImageUrl");
            contactName = intent.getStringExtra("contactName");
            if (incomingnumber != null && !incomingnumber.equalsIgnoreCase(""))
                Strincoming = incomingnumber;
            else
                Strincoming = null;
//
//            if(outgoingnumber != null)
//                Stroutgoing = outgoingnumber;
            if (ImageUrl != null)
                a = ImageUrl;

            if (contactName != null)
                tempName = contactName;
            Log.e("RecordService", "incomingnumber" + ImageUrl + " " + "outgoingnumber" + outgoingnumber);
        } catch (Exception e) {

        }

        /*
        * For off automatic recording
        * */

        Log.i("CallRecorder", "RecordService::onStartCommand called while isRecording:" + isRecording);
        Log.i("RecordService", "getalldata" + isRecording);

        Context c = getApplicationContext();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);


        /*
        * For Stop Recording
        * */
//        Boolean shouldRecord = prefs.getBoolean(Preferences.PREF_RECORD_CALLS, false);
        if (pref.getAUTOSAVE_RECORDING()) {
            Log.e("pref.getAUTOSAVE_RECORDING()", "prefff" + pref.getAUTOSAVE_RECORDING());
            Boolean shouldRecord = pref.getAUTOSAVE_RECORDING();

            if (shouldRecord == false) {
                Log.i("CallRecord", "RecordService::onStartCommand with PREF_RECORD_CALLS false, not recording");
                //return START_STICKY;
//                recorder.release();
                return;
            }
        }

//
//        int audiosource = Integer.parseInt(prefs.getString(Preferences.PREF_AUDIO_SOURCE, "1"));
//        int audioformat = Integer.parseInt(prefs.getString(Preferences.PREF_AUDIO_FORMAT, "1"));
        int audiosource = 1;
        int formate = Integer.parseInt(pref.getAudioFormat());
        int audioformat = formate;

        recording = makeOutputFile(prefs);
        if (recording == null) {
            recorder = null;
            return; //return 0;
        }

        Log.i("CallRecorder", "RecordService will config MediaRecorder with audiosource: " + audiosource + " audioformat: " + audioformat);
        try {
            // These calls will throw exceptions unless you set the
            // android.permission.RECORD_AUDIO permission for your app
            recorder.reset();
            recorder.setAudioSource(audiosource);
            Log.d("CallRecorder", "set audiosource " + audiosource);
            recorder.setOutputFormat(audioformat);
            Log.d("CallRecorder", "set output " + audioformat);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            Log.d("CallRecorder", "set encoder default");
            recorder.setOutputFile(recording.getAbsolutePath());
            Log.d("CallRecorder", "set file: " + recording);
            //recorder.setMaxDuration(msDuration); //1000); // 1 seconds
            //recorder.setMaxFileSize(bytesMax); //1024*1024); // 1KB

            recorder.setOnInfoListener(this);
            recorder.setOnErrorListener(this);

            try {
                recorder.prepare();


            } catch (java.io.IOException e) {
                Log.e("CallRecorder", "RecordService::onStart() IOException attempting recorder.prepare()\n");
                Toast t = Toast.makeText(getApplicationContext(), "CallRecorder was unable to start recording: ", Toast.LENGTH_LONG);
                t.show();
                recorder = null;
                return; //return 0; //START_STICKY;
            }
            Log.d("CallRecorder", "recorder.prepare() returned");


            recorder.start();
            isRecording = true;

            Boolean newCall = pref.getNEW_CALL_NOTIFY();
            Log.i("CallRecorder", "recorder.start() returned" + newCall);

            Calendar cal = Calendar.getInstance();
            Log.e("Currenttime" + cal.getTime(), "");
            SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss");
            String formattedDate = df.format(cal.getTime());
            CuurentTime = formattedDate;
            if (newCall == true) {

                updateNotification(true);
            }
        } catch (java.lang.Exception e) {
            Toast t = Toast.makeText(getApplicationContext(), "CallRecorder was unable to start recording: ", Toast.LENGTH_LONG);
            t.show();

            Log.e("CallRecorder", "RecordService::onStart caught unexpected exception", e);
            recorder = null;
        }

        return; //return 0; //return START_STICKY;
    }

    public void onDestroy() {
        super.onDestroy();

        if (null != recorder) {

            Log.i("CallRecorder", "RecordService::onDestroy calling recorder.release()");
            isRecording = false;
            recorder.release();

            Log.e("RecordService", "path" + recording + "  " + recordingDate);
            /*
            // encrypt the recording
            String keyfile = "/sdcard/keyring";
            try {
                //PGPPublicKey k = readPublicKey(new FileInputStream(keyfile));
                test();
            } catch (java.security.NoSuchAlgorithmException e) {
                Log.e("CallRecorder", "RecordService::onDestroy crypto test failed: ", e);
            }
            //encrypt(recording);
            */
        }
        Boolean newCall = pref.getNEW_CALL_NOTIFY();
        if (newCall == true) {
            updateNotification(false);
        } else {
            String number = null;
            if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {

//                number = outgoingnumber;
                number = outgoingnumber.substring(outgoingnumber.length() - 10);

            } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
//                number = Strincoming;
                number = Strincoming.substring(Strincoming.length() - 10);
            }

            if (pref.getFilterDefault().equalsIgnoreCase("Record all")) {
                RecordingAll(number);
            } else if (pref.getFilterDefault().equalsIgnoreCase("Ignore all")) {
                RecordingSelected(number);
            } else if (pref.getFilterDefault().equalsIgnoreCase("Ignore contacts")) {
                int size = db.getRecordUser(number).size();
                if (size > 0) {
                    RecordingSelected(number);
                    CheckName = true;
                }

                if (CheckName == false) {
                    if (tempName == null) {
                        RecordingSelected(number);
                    }
                }
            }

        }
    }

    public void RecordingAll(String number) {

        int size = db.getBlockUser(number).size();
        Log.e("sizee", "sizee" + size + " n0" + number);
        if (size == 0) {
            if (askWhatToDo.equalsIgnoreCase("Ask what to do")) {

//                showDialog();
                Intent intent = new Intent(RecordService.this, PopupActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("name", tempName);
                intent.putExtra("image", a);
                intent.putExtra("CuurentTime", CuurentTime);
                intent.putExtra("save", "false");
                if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {
                    intent.putExtra("number", outgoingnumber);
                    intent.putExtra("type", "outgoing");
                } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
                    intent.putExtra("number", Strincoming);
                    intent.putExtra("type", "incoming");
                }
                intent.putExtra("dayoftheweek", dayoftheweek);
                intent.putExtra("recording", String.valueOf(recording));
                startActivity(intent);

            } else if (askWhatToDo.equalsIgnoreCase("Save the recording")) {
                int value = db.getAllCallRecordDetail().size();
                int minId = db.minCallerId();
                int inboxSize = Integer.parseInt(pref.getFilterInbox());
                Log.e("database " + value, "min id" + db.minCallerId() + "prefe " + inboxSize);
                if (value < inboxSize) {
                    insertInDatabase();
                } else {
                    db.deleteItem(minId);
                    insertInDatabase();
                }
            } else if (askWhatToDo.equalsIgnoreCase("Dont`s save the recording")) {
//                Toast.makeText(RecordService.this, "dont", Toast.LENGTH_SHORT).show();
            }

            Boolean afterCall = pref.getAFTER_CALL_NOTIFY();
            if (afterCall == true) {
                endCallNotification();
            }
        }
    }
    // methods to handle binding the service

    public void RecordingSelected(String number) {
        int size = db.getRecordUser(number).size();
        Log.e("sizee", "sizee" + size + " n0" + number);
//        if (size > 0) {
        if (askWhatToDo.equalsIgnoreCase("Ask what to do")) {

//                showDialog();
            Intent intent = new Intent(RecordService.this, PopupActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra("name", tempName);
            intent.putExtra("image", a);
            intent.putExtra("save", "false");
            intent.putExtra("CuurentTime", CuurentTime);

            if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {
                intent.putExtra("number", outgoingnumber);
                intent.putExtra("type", "outgoing");
            } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
                intent.putExtra("number", Strincoming);
                intent.putExtra("type", "incoming");
            }
            intent.putExtra("dayoftheweek", dayoftheweek);
            intent.putExtra("recording", String.valueOf(recording));
            startActivity(intent);
        } else if (askWhatToDo.equalsIgnoreCase("Save the recording")) {
            int value = db.getAllCallRecordDetail().size();
            int minId = db.minCallerId();
            int inboxSize = Integer.parseInt(pref.getFilterInbox());
            Log.e("database " + value, "min id" + db.minCallerId() + "prefe " + inboxSize);
            if (value < inboxSize) {
                insertInDatabase();
            } else {
                db.deleteItem(minId);
                insertInDatabase();
            }
        } else if (askWhatToDo.equalsIgnoreCase("Dont`s save the recording")) {
//                Toast.makeText(RecordService.this, "dont", Toast.LENGTH_SHORT).show();
        }

        Boolean afterCall = pref.getAFTER_CALL_NOTIFY();
        if (afterCall == true) {
            endCallNotification();
        }
//        }
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public boolean onUnbind(Intent intent) {
        return false;
    }

    public void onRebind(Intent intent) {
    }

    public void updateNotification(Boolean status) {


        Context c = getApplicationContext();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);

        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
        builder = new NotificationCompat.Builder(
                this);
        if (status) {
            int icon = R.drawable.ellipse;
//            CharSequence tickerText = " call from channel " + prefs.getString("1", "1");
            CharSequence tickerText = "Call Recorder";
            long when = System.currentTimeMillis();

            Notification notification = new Notification(icon, tickerText, when);

            Context context = getApplicationContext();
            CharSequence contentTitle = "CallRecorder Status";
            CharSequence contentText = "Recording";
            Intent notificationIntent = new Intent(this, RecordService.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
            contentView = new RemoteViews(getPackageName(), R.layout.notification_layout);
//            notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);
////set the button listeners

            if (pref.getAUTOSAVE_RECORDING() == false) {
                contentView.setViewVisibility(R.id.startBtn, View.VISIBLE);
            } else {
                contentView.setViewVisibility(R.id.stopBtn, View.VISIBLE);
            }

            Log.e("contentViewzad", "contentView" + contentView);
            setListeners(contentView);

            notification.contentView = contentView;
            notification.flags |= Notification.FLAG_ONGOING_EVENT;
//            notification = builder.setContentIntent(contentIntent)
//                    .setSmallIcon(R.drawable.ellipse).setTicker(contentTitle)
//                    .setAutoCancel(true).setContentTitle(contentText)
//                    .setContentText(contentText).build();
            mNotificationManager.notify(RECORDING_NOTIFICATION_ID, notification);
        } else {

            mNotificationManager.cancel(RECORDING_NOTIFICATION_ID);
            Boolean shouldRecord = pref.getAUTOSAVE_RECORDING();
            if (shouldRecord == true) {
                String number = null;
                if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {
//                    number = outgoingnumber;
                    number = outgoingnumber.substring(outgoingnumber.length() - 10);

                } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
//                    number = Strincoming;
                    number = Strincoming.substring(Strincoming.length() - 10);
                }


                if (pref.getFilterDefault().equalsIgnoreCase("Record all")) {
                    RecordingAll(number);
                } else if (pref.getFilterDefault().equalsIgnoreCase("Ignore all")) {
                    RecordingSelected(number);
                } else if (pref.getFilterDefault().equalsIgnoreCase("Ignore contacts")) {
                    int size = db.getRecordUser(number).size();
                    Log.e("recorde", "zzz1" + size);

                    if (size > 0) {
                        RecordingSelected(number);
                        CheckName = true;
                    }

                    if (CheckName == false) {
                        if (tempName == null) {
                            RecordingSelected(number);
                        }
                    }
                }

            }
            Boolean afterCall = pref.getAFTER_CALL_NOTIFY();
            if (afterCall == true) {
                endCallNotification();
            }
        }
    }

    //
    public void setListeners(RemoteViews view) {
        //TODO screencapture listener
        Intent radio = new Intent(RecordService.this, NotificationBroadcast.class);
        radio.putExtra("DO", "start");
        String type = null;

        if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {
//                    number = outgoingnumber;
            type = "outgoing";
            radio.putExtra("monumber", outgoingnumber);
        } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
//                    number = Strincoming;
            type = "incoming";
            radio.putExtra("monumber", Strincoming);
        }
        radio.putExtra("type", type);
        PendingIntent pRadio = PendingIntent.getBroadcast(RecordService.this, 0, radio, 0);
        view.setOnClickPendingIntent(R.id.startBtn, pRadio);
/************************************************************************************/
        //TODO screen size listener
        Intent volume = new Intent(RecordService.this, NotificationBroadcast.class);
        volume.putExtra("DO", "stop");
        PendingIntent pVolume = PendingIntent.getBroadcast(RecordService.this, 1, volume, 0);
        view.setOnClickPendingIntent(R.id.stopBtn, pVolume);

        Log.e("RecordService", "service click");

    }

    private void endCallNotification() {
        Context c = getApplicationContext();
        db = new DatabaseHelper(getBaseContext());
        int value = db.getAllCallRecordDetail().size();
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);

        String ns = Context.NOTIFICATION_SERVICE;
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);
        builder = new NotificationCompat.Builder(
                this);
        int icon = R.drawable.grayuser;
//            CharSequence tickerText = " call from channel " + prefs.getString("1", "1");
        CharSequence tickerText = "Call Recorder";
        long when = System.currentTimeMillis();

        Notification notification = new Notification(icon, tickerText, when);

        Context context = getApplicationContext();
        CharSequence contentTitle = "New Recording";
        CharSequence contentText = "You have " + value + " new recording ";
        Intent notificationIntent = new Intent(this, RecordService.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

//            notification.setLatestEventInfo(context, contentTitle, contentText, contentIntent);

//            Intent intent = new Intent(this, RecordService.class);
//            intent.setAction(ACTION_STOP);
//            PendingIntent pendingIntent = PendingIntent.getService(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
//            builder.addAction(R.drawable.stopp, "Stop", pendingIntent);

        notification = builder.setContentIntent(contentIntent)
                .setSmallIcon(R.drawable.ellipse).setTicker(contentTitle)
                .setAutoCancel(true).setContentTitle(contentTitle)
                .setContentText(contentText).build();
        mNotificationManager.notify(RECORDING_NOTIFICATION_ID, notification);

    }


    // MediaRecorder.OnInfoListener
    public void onInfo(MediaRecorder mr, int what, int extra) {
        Log.i("CallRecorder", "RecordService got MediaRecorder onInfo callback with what: " + what + " extra: " + extra);
        isRecording = false;
    }

    // MediaRecorder.OnErrorListener
    public void onError(MediaRecorder mr, int what, int extra) {
        Log.e("CallRecorder", "RecordService got MediaRecorder onError callback with what: " + what + " extra: " + extra);
        isRecording = false;
        mr.release();
    }

    public void insertInDatabase() {


        Calendar c = Calendar.getInstance();
        Log.e("Currenttime" + c.getTime(), "");
        SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss");
        String formattedDate = df.format(c.getTime());


        Date date1 = null;
        Date date2 = null;
        try {
            date1 = df.parse(CuurentTime);
            date2 = df.parse(formattedDate);


        } catch (ParseException e) {
            e.printStackTrace();
        }

        long difference = date2.getTime() - date1.getTime();
//        int days = (int) (difference / (1000 * 60 * 60 * 24));
//        int hours = (int) ((difference - (1000 * 60 * 60 * 24 * days)) / (1000 * 60 * 60));
//        int min = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) / (1000 * 60);
//        int sec = (int) (difference - (1000 * 60 * 60 * 24 * days) - (1000 * 60 * 60 * hours)) - (1000 * 60 * 60 * min) ;
//        hours = (hours < 0 ? -hours : hours);

        long diffSeconds = difference / 1000 % 60;
        long diffMinutes = difference / (60 * 1000) % 60;
        long diffHours = difference / (60 * 60 * 1000) % 24;
//        Toast.makeText(getApplicationContext(), "" + diffHours + " days" + diffSeconds + "min " + diffMinutes, Toast.LENGTH_LONG).show();

        MainActivity.deleteFlag = true;
        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE", Locale.US);
        Calendar calendar = Calendar.getInstance();
        dayoftheweek = dayFormat.format(calendar.getTime());
        Log.e("day", "" + dayoftheweek);

        Log.e("RecordService", "incomingnumber" + incomingnumber);
        CallRecorderModel callRecorderModel = new CallRecorderModel();
        callRecorderModel.setCallername(tempName);
        callRecorderModel.setCallerimage(a);
        Log.e("callRecorderModel", "inserted" + tempName);

        String number = null;
        callRecorderModel.setDelete("false");
        callRecorderModel.setUpload("false");
//        retrieveContactPhoto();
        Log.e("outgoingnumber", "zzz" + outgoingnumber);
        Log.e("substring", "zzz" + Strincoming);
        if (outgoingnumber != null && !outgoingnumber.isEmpty() && !outgoingnumber.equals("null")) {
            String substr = outgoingnumber.substring(outgoingnumber.length() - 10);
            Log.e("substring", "" + outgoingnumber);
            callRecorderModel.setCallernumber(substr);
            callRecorderModel.setType("outgoing");
            number = outgoingnumber;
//        }else if (!Strincoming.equalsIgnoreCase("0")&&Strincoming.length()!=0) {
        } else if (Strincoming != null && !Strincoming.isEmpty() && !Strincoming.equals("null")) {
            String substr2 = Strincoming.substring(Strincoming.length() - 10);
            callRecorderModel.setCallernumber(substr2);
            callRecorderModel.setType("incoming");
            number = Strincoming;
        }

//        callRecorderModel.setTransactionDate("1470220846862");
//        Log.e("myCurrentTimeMillis","myCurrentTimeMillis"+ String.valueOf(myCurrentTimeMillis));
        callRecorderModel.setCallingtime(dayoftheweek);
//        Toast.makeText(getApplicationContext(), "" +diffHours + " days" +diffSeconds+ "min " + diffMinutes, Toast.LENGTH_LONG).show();

        callRecorderModel.setCallDuration(diffHours + ":" + diffMinutes + ":" + diffSeconds);
        callRecorderModel.setRecordingpath(String.valueOf(recording));
        int value = db.getContactToSave(number).size();
        if (value > 0) {
            callRecorderModel.setSaved("true");
        } else {
            callRecorderModel.setSaved("false");

        }
        Log.e("contactosave", "" + value);
        db.insertCallRecorder(callRecorderModel);
        String autosaveTocloud = String.valueOf(pref.getAUTOSAVE()) + "";
        if (autosaveTocloud.equalsIgnoreCase("true")) {
            if (pref.getDriveLogin()) {
                Intent myIntent2 = new Intent(RecordService.this, AutoSaveToCloudService.class);
                startService(myIntent2);
            } else {
//                Toast.makeText(RecordService.this, "Please login in google drive", Toast.LENGTH_SHORT).show();
            }
        }

        stopSelf();

    }

    private void showDialog() {
//        AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(RecordService.this, R.style.CustomAlertDialogStyle));
        AlertDialog.Builder builder = new AlertDialog.Builder(RecordService.this, R.style.MyMaterialTheme);

        builder.setTitle("Ask what to do");
//        builder.setIcon(R.drawable.icon);
        builder.setMessage("You want to save your call recording file?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                //Do something
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);
        alert.show();
    }
}
