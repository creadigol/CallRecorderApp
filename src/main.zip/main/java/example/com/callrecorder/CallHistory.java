package example.com.callrecorder;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

import example.com.callrecorder.Adapter.CallHistoryAdapter;
import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.database.DatabaseHelper;

public class CallHistory extends AppCompatActivity {
    RecyclerView rvText;
    CallHistoryAdapter _TextAdapter;
    String edttext;
    ArrayList<CallRecorderModel> subliminalModels;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_history);

        rvText = (RecyclerView) findViewById(R.id.rcallhistory);
        Intent i =getIntent();
        String number = String.valueOf(i.getStringExtra("callingNumber"));
        DatabaseHelper dbcontroller = new DatabaseHelper(getApplicationContext());
        subliminalModels = dbcontroller.getParticularUserData(number);

        Log.e("Array list size", "" + subliminalModels.size());

        setTextAdapter();
        Toolbar();
        _TextAdapter = new CallHistoryAdapter(getApplicationContext(), subliminalModels);

    }
    public void setTextAdapter() {
        _TextAdapter = new CallHistoryAdapter(getApplicationContext(), subliminalModels);

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(
                getApplicationContext()) {
            @Override
            protected int getExtraLayoutSpace(RecyclerView.State state) {
                return 150;
            }
        };
        rvText.setLayoutManager(linearLayoutManager);
        rvText.setAdapter(_TextAdapter);
    }
    public void Toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.appbar_details);
        setSupportActionBar(toolbar);
        TextView tvCatTitle = (TextView) toolbar.findViewById(R.id.tv_toolbar_name);
        tvCatTitle.setText(getResources().getString(R.string.CallHistory));
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // handle arrow click here
        if (item.getItemId() == android.R.id.home) {
            finish(); // close this activity and return to preview activity (if there is any)
        }

        return super.onOptionsItemSelected(item);
    }


}
