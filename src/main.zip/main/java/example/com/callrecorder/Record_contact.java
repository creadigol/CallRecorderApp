package example.com.callrecorder;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import example.com.callrecorder.Adapter.IgnorecontactAdapter;
import example.com.callrecorder.Adapter.RecordcontactAdapter;
import example.com.callrecorder.Model.IgnorecontactModel;
import example.com.callrecorder.database.DatabaseHelper;

/**
 * Created by ravi on 26-10-2016.
 */

public class Record_contact extends AppCompatActivity implements View.OnClickListener {
    RecyclerView rv_igone;
    ImageView iv_ignorecontact;
    public static final int PICK_CONTACT = 100;
    ArrayList<IgnorecontactModel> ignorecontactModels;
    DatabaseHelper db;
    int id;
    RecordcontactAdapter ignorecontactAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ignore_contact);
        toolbar();

    }

    public void toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_igone);
        setSupportActionBar(toolbar);
        TextView tv_toolbar = (TextView) toolbar.findViewById(R.id.tv_toolbar_ignore);
        iv_ignorecontact = (ImageView) toolbar.findViewById(R.id.iv_plus);
        iv_ignorecontact.setOnClickListener(this);
        tv_toolbar.setText("contacts to Record");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }

    View.OnClickListener onclicklistner=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int position=(int) v.getTag();
            IgnorecontactModel ignorecontactModel= ignorecontactModels.get(position);
            id=ignorecontactModel.getCallerid();
            dialogBox();

        }
    };
    public void ignoredata() {
        rv_igone = (RecyclerView) findViewById(R.id.rv_ignore);
        ignorecontactModels = new ArrayList<>();
        ignorecontactModels= db.getAllIRecordcontactModels();
        if (ignorecontactModels.size() > 0) {
            rv_igone.setHasFixedSize(true);
            rv_igone.setItemAnimator(new DefaultItemAnimator());
            rv_igone.setLayoutManager(new LinearLayoutManager(this));
            ignorecontactAdapter = new RecordcontactAdapter(getApplicationContext(), ignorecontactModels,onclicklistner);
            rv_igone.setAdapter(ignorecontactAdapter);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_plus:
//                readcontact();
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
                startActivityForResult(i, PICK_CONTACT);
                break;
        }
    }
    public void dialogBox() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(Record_contact.this);

        // Setting Dialog Title
        alertDialog.setTitle("Confirm Delete...");

        // Setting Dialog Message
        alertDialog.setMessage("Are you sure you want delete this?");



        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int which) {

                // Write your code here to invoke YES event
               db.deleteRecordcontact(id);
                ignoredata();

            }
        });

        // Setting Negative "NO" Button
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to invoke NO event
//                Toast.makeText(getApplicationContext(), "You clicked on NO", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        // Showing Alert Message
        alertDialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        db = new DatabaseHelper(getApplicationContext());
        ignoredata();
    }

    public void readcontact() {
        try {
//            Intent intent = new Intent(Intent.ACTION_PICK, Uri.parse("content://contacts/people"));
//            startActivityForResult(intent, PICK_CONTACT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

   /* public void readcontact(){
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, Uri.parse("content://contacts/people"));
            startActivityForResult(intent, PICK_CONTACT);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
   /* public void onActivityResult(int reqCode, int resultCode, Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        switch (reqCode) {
            case (PICK_CONTACT):
                if (resultCode == Activity.RESULT_OK) {
                    Uri contactData = data.getData();
                    Cursor c = managedQuery(contactData, null, null, null, null);
                    startManagingCursor(c);
                    if (c.moveToFirst()) {
                        String name = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.DISPLAY_NAME));
                        String number = c.getString(c.getColumnIndexOrThrow(ContactsContract.Contacts.));
                        Toast.makeText(this, name + " has name " + name, Toast.LENGTH_LONG).show();
                        Toast.makeText(this, name + " has number " + number, Toast.LENGTH_LONG).show();
                    }

                }
                break;
        }

    }*/


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        IgnorecontactModel ignorecontactModel = new IgnorecontactModel();
        if (requestCode == PICK_CONTACT) {
            if (resultCode == RESULT_OK) {
                Uri contactData = data.getData();
                Cursor cursor = managedQuery(contactData, null, null, null, null);
                cursor.moveToFirst();

                String number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                Toast.makeText(this, " has number " + number, Toast.LENGTH_LONG).show();
                Toast.makeText(this, " has name " + name, Toast.LENGTH_LONG).show();


//                ignorecontactModel.setContactname(name);
//                ignorecontactModel.setContactnumber(number);
                String input = number.replace(" ", "");
                db.insertRecorddata(name,input);
            }
        }
    }
}
