/*
package example.com.callrecorder;

import android.app.Application;
import android.content.Context;

import com.nostra13.universalimageloader.cache.memory.impl.WeakMemoryCache;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;

import example.com.callrecorder.Utils.PreferenceSettings;

*/
/**
 * Created by ravi on 26-10-2016.
 *//*


public class CallrecorderApplication extends Application {

    private static CallrecorderApplication mInstance;
    private static ImageLoader mImageLoader;
    private static Context mContext;
    private PreferenceSettings mPreferenceSettings;
    public static final String TAG = CallrecorderApplication .class
            .getSimpleName();

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        mContext = getApplicationContext();
        mPreferenceSettings = getPreferenceSettings();

    }

    public static synchronized CallrecorderApplication getInstance() {
        return mInstance;
    }

    public ImageLoader getImageLoader(){
        if(mImageLoader == null){
            // UNIVERSAL IMAGE LOADER SETUP
            ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
                    mContext)
                    .defaultDisplayImageOptions(getDefaultOptions())
                    .memoryCache(new WeakMemoryCache())
                    .diskCacheSize(100 * 1024 * 1024).build();

            mImageLoader = ImageLoader.getInstance();
            mImageLoader.init(config);
            // END - UNIVERSAL IMAGE LOADER SETUP
        }
        return mImageLoader;
    }

    public DisplayImageOptions getDefaultOptions(){
        DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder()
                .cacheOnDisk(true).cacheInMemory(true)
                .imageScaleType(ImageScaleType.EXACTLY)
                .displayer(new FadeInBitmapDisplayer(300)).build();
        return defaultOptions;
    }

    public PreferenceSettings getPreferenceSettings() {
        if (mPreferenceSettings == null) {
            mPreferenceSettings = new PreferenceSettings(mContext);
        }
        return mPreferenceSettings;
    }

}
*/
