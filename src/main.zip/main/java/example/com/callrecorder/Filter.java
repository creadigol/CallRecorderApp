package example.com.callrecorder;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import example.com.callrecorder.Utils.PreferenceSettings;

/**
 * Created by ravi on 24-10-2016.
 */

public class Filter extends AppCompatActivity implements View.OnClickListener{
    RadioButton radioButton,rb5,rb10,rb20,rb40,rb100,rb200,rb300,rb500,rb1000,rb_recordall,rb_ignoreall,rb_ignorecontact;
    String st_radiobtn;
    PreferenceSettings pref;
    LinearLayout ll_inboxview,ll_defualt,ll_ignore_contact,ll_record_contact,ll_record_contactToSave;
    TextView sizeTextView,mode,tvCR,tvCR2,tvCI2,tvCI;

 //   SharedPreferences pref_inbox;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);
        pref=new PreferenceSettings(Filter.this);
        ll_inboxview=(LinearLayout)findViewById(R.id.ll_inboxview);
        ll_defualt=(LinearLayout)findViewById(R.id.ll_defualt);
        ll_record_contactToSave=(LinearLayout)findViewById(R.id.contactToSave);
        sizeTextView = (TextView) findViewById(R.id.sizeTextView);

        tvCR = (TextView) findViewById(R.id.tvCR);
        tvCR2 = (TextView) findViewById(R.id.tvCR2);
        tvCI2 = (TextView) findViewById(R.id.tvCI2);
        tvCI = (TextView) findViewById(R.id.tvCI);

        mode = (TextView) findViewById(R.id.mode);
        ll_ignore_contact=(LinearLayout)findViewById(R.id.ll_ignore);
        ll_record_contact=(LinearLayout)findViewById(R.id.ll_record);
        sizeTextView.setText(pref.getFilterInbox().toString());


        ll_inboxview.setOnClickListener(this);
        ll_defualt.setOnClickListener(this);
        ll_ignore_contact.setOnClickListener(this);
        ll_record_contact.setOnClickListener(this);
        ll_record_contactToSave.setOnClickListener(this);
        CheckVisiblity();
        toolbar();

    }

    public void CheckVisiblity(){
        if(pref.getFilterDefault()!=null){
            if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Recordall))){
//                rb_recordall.setChecked(true);
                mode.setText(getResources().getString(R.string.Recordall));
                ll_record_contact.setClickable(false);

                tvCR.setTextColor(getResources().getColor(R.color.colortrasprent));
                tvCR2.setTextColor(getResources().getColor(R.color.colortrasprent));
                tvCI.setTextColor(getResources().getColor(R.color.filtergray));
                tvCI2.setTextColor(getResources().getColor(R.color.filtergray));
                ll_ignore_contact.setClickable(true);
            }else if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Ignoreall))){
//                rb_ignoreall.setChecked(true);
                mode.setText(getResources().getString(R.string.Ignoreall));
                ll_record_contact.setClickable(true);
                ll_ignore_contact.setClickable(false);

                tvCR.setTextColor(getResources().getColor(R.color.filtergray));
                tvCR2.setTextColor(getResources().getColor(R.color.filtergray));
                tvCI.setTextColor(getResources().getColor(R.color.colortrasprent));
                tvCI2.setTextColor(getResources().getColor(R.color.colortrasprent));
            }else if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Ignorecontacts))){
//                rb_ignorecontact.setChecked(true);
                mode.setText(getResources().getString(R.string.Ignorecontacts));
                ll_record_contact.setClickable(true);
                ll_ignore_contact.setClickable(false);


                tvCR.setTextColor(getResources().getColor(R.color.filtergray));
                tvCR2.setTextColor(getResources().getColor(R.color.filtergray));
                tvCI.setTextColor(getResources().getColor(R.color.colortrasprent));
                tvCI2.setTextColor(getResources().getColor(R.color.colortrasprent));
            }
        }
    }
    public void toolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_filter);
        setSupportActionBar(toolbar);
        TextView tv_toolbar=(TextView)toolbar.findViewById(R.id.tv_toolbar_name);
        tv_toolbar.setText(getResources().getString(R.string.Filter));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
    public void radiobutton()
    {
        if(pref.getFilterInbox()!=null) {
            if (pref.getFilterInbox().equalsIgnoreCase("5")) {
                rb5.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("10")) {
                rb10.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("20")) {
                rb20.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("40")) {
                rb40.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("100")) {
                rb100.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("200")) {
                rb200.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("300")) {
                rb300.setChecked(true);
            }else if (pref.getFilterInbox().equalsIgnoreCase("500(Pro)")) {
                rb500.setChecked(true);

            }else if (pref.getFilterInbox().equalsIgnoreCase("1000(Pro)")) {
                rb1000.setChecked(true);
            }
        }
    }
    public void defualtmode()
    {
        if(pref.getFilterDefault()!=null){
            if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Recordall))){
                rb_recordall.setChecked(true);
//                mode.setText("Record all");
            }else if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Ignoreall))){
                rb_ignoreall.setChecked(true);
//                mode.setText("Ignore all");
            }else if(pref.getFilterDefault().equalsIgnoreCase(getResources().getString(R.string.Ignorecontacts))){
                rb_ignorecontact.setChecked(true);
//                mode.setText("Ignore contacts");
            }
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                finish();

                break;
        }
        return true;
    }
    private void dialogInboxSize() {

        final Dialog dialog = new Dialog(Filter.this);
        dialog.setContentView(R.layout.dialog_inbox_size);
        dialog.setTitle(getResources().getString(R.string.Inboxsize));

        RadioGroup rg_group = (RadioGroup)dialog.findViewById(R.id.rginbox);
        TextView btn_cancel=(TextView) dialog.findViewById(R.id.btn_cancel);
        rb5=(RadioButton)dialog.findViewById(R.id.rb5);
        rb10=(RadioButton)dialog.findViewById(R.id.rb10);
        rb20=(RadioButton)dialog.findViewById(R.id.rb20);
        rb40=(RadioButton)dialog.findViewById(R.id.rb40);
        rb100=(RadioButton)dialog.findViewById(R.id.rb100);
        rb200=(RadioButton)dialog.findViewById(R.id.rb200);
        rb300=(RadioButton)dialog.findViewById(R.id.rb300);
        rb500=(RadioButton)dialog.findViewById(R.id.rb500);
        rb1000=(RadioButton)dialog.findViewById(R.id.rb1000);
        radiobutton();
        rg_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                @Override
                                                public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                    radioButton = (RadioButton) dialog.findViewById(checkedId);
                                                    st_radiobtn = (String) radioButton.getText();


                                                    if(st_radiobtn.equalsIgnoreCase("500(Pro)")){
                                                        dialog.dismiss();
                                                        ProDialog();
                                                    }else if(st_radiobtn.equalsIgnoreCase("1000(Pro)")){
                                                        dialog.dismiss();
                                                        ProDialog();

                                                    }else {
                                                        pref.setFilterInbox(st_radiobtn);
                                                        sizeTextView.setText(pref.getFilterInbox().toString());
                                                    }
                                                    dialog.dismiss();
                                                }
                                            }
        );
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

            }
        });
        dialog.show();
    }
    private void  dialogDefualt() {

        final Dialog dialog = new Dialog(Filter.this);
        dialog.setContentView(R.layout.dialog_defualt);
        dialog.setTitle(getResources().getString(R.string.DefaultMode));
        RadioGroup rg_group = (RadioGroup)dialog.findViewById(R.id.rginbox);
        TextView tv_cencal=(TextView) dialog.findViewById(R.id.tv_cancel);

        rb_recordall=(RadioButton)dialog.findViewById(R.id.rb_recordall);
        rb_ignoreall=(RadioButton)dialog.findViewById(R.id.rb_ignoreall);
        rb_ignorecontact=(RadioButton)dialog.findViewById(R.id.rb_ignorecontact);
        defualtmode();
        rg_group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                                                @Override
                                                public void onCheckedChanged(RadioGroup group, int checkedId) {
                                                    radioButton = (RadioButton) dialog.findViewById(checkedId);
                                                    st_radiobtn = (String) radioButton.getText();
                                                    pref.setFilterDefault(st_radiobtn);
                                                    // Toast.makeText(getApplicationContext(), a, Toast.LENGTH_SHORT).show();
//                                                    SharedPreferences.Editor editor = pref_inbox.edit();
//                                                    editor.putString("size", st_radiobtn);
//                                                    editor.commit();
                                                    mode.setText(st_radiobtn.toString());
                                                    CheckVisiblity();
//                                                    Toast.makeText(getApplicationContext(), st_radiobtn, Toast.LENGTH_SHORT).show();
                                                    // Reading from SharedPreferences
//                                                    String value = pref_audio_format.getString("size", "");
//                                                    Toast.makeText(getApplicationContext(), value, Toast.LENGTH_SHORT).show();
                                                    dialog.dismiss();
                                                }
                                            }
        );
        tv_cencal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
               // pref.getFilterDefault();
                //System.out.println("Default value"+pref.getFilterDefault());
            }
        });


        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.ll_inboxview:
                dialogInboxSize();
                break;
            case R.id.ll_defualt:
                dialogDefualt();
                break;
            case R.id.ll_ignore:
                Intent i=new Intent(Filter.this,Ignore_contact.class);
                startActivity(i);
                break;
            case R.id.ll_record:
                Intent recordCon=new Intent(Filter.this,Record_contact.class);
                startActivity(recordCon);
                break;
            case R.id.contactToSave:
                Intent ContactToSave=new Intent(Filter.this,ContactToSave.class);
                startActivity(ContactToSave);

                break;
        }
    }
    private void ProDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Filter.this);
        builder.setTitle(getResources().getString(R.string.pro));
        builder.setMessage(getResources().getString(R.string.Purchase));

        String positiveText = getString(android.R.string.ok);
        builder.setPositiveButton(positiveText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // positive button logic
                    }
                });

        String negativeText = getString(android.R.string.cancel);
        builder.setNegativeButton(negativeText,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // negative button logic
                    }
                });

        AlertDialog dialog = builder.create();
        // display dialog
        dialog.show();
    }
}
