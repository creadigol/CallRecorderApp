package example.com.callrecorder.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.Model.IgnorecontactModel;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import example.com.callrecorder.Adapter.IgnorecontactAdapter;
import example.com.callrecorder.Model.CallRecorderModel;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import example.com.callrecorder.Model.CallRecorderModel;
import example.com.callrecorder.Model.IgnorecontactModel;


/**
 * Created by ZAD on 10/26/2015.
 */
public class DatabaseHelper extends SQLiteOpenHelper {


    /**
     * Created by ZAD on 10/26/2015.
     */

    //CallRecorder
    public static final String TABLE_USERRECORDDATA = "userrecord";
    public static final String TABLE_IGNORECONTACT = "ignorerecord";
    public static final String TABLE_CONTACTTORECORD = "contacttorecord";
    public static final String TABLE_CONTACTTOSAVE = "contacttosave";
    public static final String FIELD_CALLERID = "callerid";
    public static final String FIELD_CALLERNAME = "callername";
    public static final String FIELD_CALLERIMAGE = "callerimage";
    public static final String FIELD_CALLERNUMBER = "callernumber";
    public static final String FIELD_CALLINGDATE = "callingdate";
    public static final String FIELD_CALLINGTIME = "callingtime";
    public static final String FIELD_CALLERTYPE = "type";
    public static final String FIELD_CALLERNOTES = "usernotes";
    public static final String FIELD_CALLERRECORDINGPATH = "recordingpath";
    public static final String FIELD_SAVED = "save";
    public static final String FIELD_DALETE = "del";
    public static final String FIELD_SUBJECT = "subject";
    public static final String FIELD_UPLOAD = "upload";
    public static final String FIELD_DURATION = "duration";

    //ignore contact
    public static final String FIELD_IGNORE_ID = "id";
    public static final String FIELD_IGNORE_NAME = "name";
    public static final String FIELD_IGNORE_NUMBER = "number";

    // contact to record
    public static final String FIELD_CRECORD_ID = "id";
    public static final String FIELD_CRECORD_NAME = "name";
    public static final String FIELD_CRECORD_NUMBER = "number";

    // contact to save
    public static final String FIELD_CTOSAVE_ID = "id";
    public static final String FIELD_CTOSAVE_NAME = "name";
    public static final String FIELD_CTOSAVE_NUMBER = "number";

    private static final String TAG = "CallRecorder";
    private static final String DATABASE_NAME = "CallRecorder";
    private static final int DATABASE_VERSION = 1;
    public static example.com.callrecorder.database.DatabaseHelper mInstance = null;
    private static Context mContext;
    private SQLiteDatabase mDb;
    private example.com.callrecorder.database.DatabaseHelper mDbHelper;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static example.com.callrecorder.database.DatabaseHelper getInstance(Context context) {
        mContext = context;
        if (mInstance == null) {
            mInstance = new example.com.callrecorder.database.DatabaseHelper(context.getApplicationContext());
        }
        return mInstance;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //CallRecorder
        String CREATE_USER_WISHLIST_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_USERRECORDDATA + " ( "
                + FIELD_CALLERID + " INTEGER  PRIMARY KEY autoincrement, "
                + FIELD_CALLERNAME + " VARCHAR, "
                + FIELD_CALLERIMAGE + " VARCHAR, "
                + FIELD_CALLERNUMBER + " INTEGER, "
                + FIELD_CALLINGDATE + " VARCHAR, "
                + FIELD_DURATION + " VARCHAR, "
                + FIELD_UPLOAD + " VARCHAR, "
                + FIELD_CALLINGTIME + " VARCHAR, "
                + FIELD_CALLERTYPE + " VARCHAR, "
                + FIELD_CALLERNOTES + " VARCHAR, "
                + FIELD_SUBJECT + " VARCHAR, "
                + FIELD_DALETE + " VARCHAR, "
                + FIELD_SAVED + " VARCHAR, "
                + FIELD_CALLERRECORDINGPATH + " VARCHAR" +
                ");";
        db.execSQL(CREATE_USER_WISHLIST_TABLE);

        Log.e("create wish list>>", "create wishlist table");

        String CREATE_IGNORE_CONTACT_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_IGNORECONTACT + " ( "
                + FIELD_IGNORE_ID + " INTEGER  PRIMARY KEY autoincrement, "
                + FIELD_IGNORE_NAME + " VARCHAR, "
                + FIELD_IGNORE_NUMBER + " VARCHAR" + ");";
        db.execSQL(CREATE_IGNORE_CONTACT_TABLE);

        String CREATE_CONTACT_TO_RECORD_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_CONTACTTORECORD+ " ( "
                + FIELD_CRECORD_ID + " INTEGER  PRIMARY KEY autoincrement, "
                + FIELD_CRECORD_NAME + " VARCHAR, "
                + FIELD_CRECORD_NUMBER + " VARCHAR" + ");";
        db.execSQL(CREATE_CONTACT_TO_RECORD_TABLE);

        String CREATE_CONTACT_TO_SAVE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_CONTACTTOSAVE+ " ( "
                + FIELD_CRECORD_ID + " INTEGER  PRIMARY KEY autoincrement, "
                + FIELD_CRECORD_NAME + " VARCHAR, "
                + FIELD_CRECORD_NUMBER + " VARCHAR" + ");";
        db.execSQL(CREATE_CONTACT_TO_SAVE_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERRECORDDATA + ";");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_IGNORECONTACT + ";");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTTORECORD + ";");
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTTOSAVE + ";");

        onCreate(db);
    }


//CallRecorder

    public boolean insertCallRecorder(CallRecorderModel callRecorder) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();


        ContentValues contentValues = new ContentValues();

        int itemID = callRecorder.getCallerid();

//
//        String checkUser = "select " + FIELD_CALLERID + " from " + TABLE_USERRECORDDATA + " where " + FIELD_CALLERID + "=" + itemID;
//        Cursor cursor = db.rawQuery(checkUser, null);

        try {


//            if (cursor.moveToFirst()) {
//                Log.i("SQL", "Insert CallRecorder already present");
//                contentValues.put(FIELD_CALLERID, itemID);
//
//                long check = db.update(TABLE_USERRECORDDATA, contentValues, FIELD_CALLERID + " = " + itemID, null);
//                if (check > -1) {
//                    contentValues.put(FIELD_CALLERID, itemID);
//                    contentValues.put(FIELD_CALLERNAME, callRecorder.getCallername());
//                    contentValues.put(FIELD_CALLERIMAGE, callRecorder.getCallerimage());
//                    contentValues.put(FIELD_CALLERNUMBER, callRecorder.getCallernumber());
//                    contentValues.put(FIELD_CALLINGDATE, callRecorder.getCallingdate());
//                    contentValues.put(FIELD_CALLINGTIME, callRecorder.getCallingtime());
//                    contentValues.put(FIELD_CALLERTYPE, callRecorder.getType());
//                    contentValues.put(FIELD_CALLERRECORDINGPATH, callRecorder.getRecordingpath());
//
//                    Log.i("CallRecorder update", "CallRecorder updated successfully");
//                    status = true;
//                } else {
//                    Log.i("CallRecorder update", "CallRecorder update not successful");
//                }
//            } else {


            contentValues.put(FIELD_CALLERNAME, callRecorder.getCallername());
            contentValues.put(FIELD_CALLERIMAGE, callRecorder.getCallerimage());
            contentValues.put(FIELD_CALLERNUMBER, callRecorder.getCallernumber());
            contentValues.put(FIELD_UPLOAD, callRecorder.getUpload());
            contentValues.put(FIELD_DURATION, callRecorder.getCallDuration());
            long myCurrentTimeMillis = System.currentTimeMillis();
            contentValues.put(FIELD_CALLINGDATE, myCurrentTimeMillis);
            contentValues.put(FIELD_SAVED, callRecorder.getSaved());
            contentValues.put(FIELD_DALETE, callRecorder.getDelete());
            contentValues.put(FIELD_CALLINGTIME, callRecorder.getCallingtime());
            contentValues.put(FIELD_CALLERTYPE, callRecorder.getType());
            contentValues.put(FIELD_CALLERRECORDINGPATH, callRecorder.getRecordingpath());

            long check = db.insert(TABLE_USERRECORDDATA, null, contentValues);

            if (check > -1) {
                Log.i("CallRecorderrr Insert", "CallRecorder inserted successfully" + contentValues);
                status = true;
            } else {
                Log.i("CallRecorder Insert", "CallRecorder insertion not successful");
            }
//            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
//            if (cursor != null) {
//                cursor.close();
//            }
        }

        return status;
    }

    public boolean insertIgnoredata(String name, String number) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();


        ContentValues contentValues = new ContentValues();

        try {
            contentValues.put(FIELD_IGNORE_NAME, name);
            contentValues.put(FIELD_IGNORE_NUMBER, number);

            long check = db.insert(TABLE_IGNORECONTACT, null, contentValues);

            if (check > -1) {
                Log.i("CallRecorderrr Insert", "CallRecorder inserted successfully" + contentValues);
                status = true;
            } else {
                Log.i("CallRecorder Insert", "CallRecorder insertion not successful");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return status;
    }

    public boolean insertRecorddata(String name, String number) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();


        ContentValues contentValues = new ContentValues();

        try {
            contentValues.put(FIELD_IGNORE_NAME, name);
            contentValues.put(FIELD_IGNORE_NUMBER, number);

            long check = db.insert(TABLE_CONTACTTORECORD, null, contentValues);

            if (check > -1) {
                Log.i("CallRecorderrr Insert", "CallRecorder inserted successfully" + contentValues);
                status = true;
            } else {
                Log.i("CallRecorder Insert", "CallRecorder insertion not successful");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return status;
    }

    public boolean insertContactToSave(String name, String number) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();


        ContentValues contentValues = new ContentValues();

        try {
            contentValues.put(FIELD_CTOSAVE_NAME, name);
            contentValues.put(FIELD_CTOSAVE_NUMBER, number);

            long check = db.insert(TABLE_CONTACTTOSAVE, null, contentValues);

            if (check > -1) {
                Log.i("CallRecorderrr Insert", "CallRecorder inserted successfully" + contentValues);
                status = true;
            } else {
                Log.i("CallRecorder Insert", "CallRecorder insertion not successful");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {

        }

        return status;
    }

    public ArrayList<CallRecorderModel> getAllCallRecordDetail() {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
        String query = "select * from userrecord where save='" + "false" + "'" + " ORDER BY " + FIELD_CALLERID + " DESC";
//
//        String query = "SELECT "+ TABLE_MATERIAL +".*,"+ TABLE_SIZE +"."+ FIELD_S_SIZENAME +
//                " FROM " + TABLE_MATERIAL + "," + TABLE_SIZE +
//                " WHERE " + TABLE_MATERIAL + "." + FIELD_SIZEID + "=" + TABLE_SIZE + "." + FIELD_S_SIZEID +
//                " ORDER BY " + FIELD_ITEMID + " DESC";

//
//        String que = "SELECT * FROM " + TABLE_MATERIAL + "," + TABLE_WISHLIST + "," + TABLE_SIZE + "," + TABLE_CATEGORY +
//                " WHERE " + TABLE_MATERIAL + "." + FIELD_ITEMCODE + "=" + TABLE_WISHLIST + "." + FIELD_W_ITEMCODE + " AND " + TABLE_MATERIAL + "." + FIELD_SIZEID + "=" + TABLE_SIZE + "." + FIELD_S_SIZEID + " AND " + TABLE_MATERIAL + "." + FIELD_CATID + "=" + TABLE_CATEGORY + "." + FIELD_C_CATID;

        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String upload = c.getString(c.getColumnIndex(FIELD_UPLOAD));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));
                String delete = c.getString(c.getColumnIndex(FIELD_DALETE));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setUpload(upload);
                recorder.setDelete(delete);
                recorder.setCallDuration(duration);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }

    public ArrayList<IgnorecontactModel> getAllIgnorecontactModels() {

        String query = "select * from ignorerecord";
        ArrayList<IgnorecontactModel> ignorecontactModels = new ArrayList<IgnorecontactModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerid = c.getInt(c.getColumnIndex(FIELD_IGNORE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_IGNORE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_IGNORE_NUMBER));

                IgnorecontactModel model = new IgnorecontactModel();
                model.setCallerid(callerid);
                model.setContactname(callername);
                model.setContactnumber(callernumber);

                Log.d("DBHel: ", "itemid: " + callerid);


                ignorecontactModels.add(model);
            }
        }

        return ignorecontactModels;

    }

    public ArrayList<IgnorecontactModel> getAllIRecordcontactModels() {

        String query = "select * from contacttorecord";
        ArrayList<IgnorecontactModel> ignorecontactModels = new ArrayList<IgnorecontactModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerid = c.getInt(c.getColumnIndex(FIELD_IGNORE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_IGNORE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_IGNORE_NUMBER));

                IgnorecontactModel model = new IgnorecontactModel();
                model.setCallerid(callerid);
                model.setContactname(callername);
                model.setContactnumber(callernumber);

                Log.d("DBHel: ", "itemid: " + callerid);


                ignorecontactModels.add(model);
            }
        }

        return ignorecontactModels;

    }

    public ArrayList<IgnorecontactModel> getAllIRecordcontactToSave() {

        String query = "select * from contacttosave";
        ArrayList<IgnorecontactModel> ignorecontactModels = new ArrayList<IgnorecontactModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerid = c.getInt(c.getColumnIndex(FIELD_CTOSAVE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_CTOSAVE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CTOSAVE_NUMBER));

                IgnorecontactModel model = new IgnorecontactModel();
                model.setCallerid(callerid);
                model.setContactname(callername);
                model.setContactnumber(callernumber);

                Log.d("DBHel: ", "itemid: " + callerid);


                ignorecontactModels.add(model);
            }
        }

        return ignorecontactModels;

    }
    //for deleting

    public void deleteItem(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //String SQLQuery = "DELETE * FROM " + TABLE_WISHLIST + " WHERE " + FIELD_W_ITEMCODE + " = " + id;
        String SQLQuery = "delete from userrecord where callerid='" + id + "' AND save='" + "false" + "'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return;
    }

    public void deleteignorecontact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //String SQLQuery = "DELETE * FROM " + TABLE_WISHLIST + " WHERE " + FIELD_W_ITEMCODE + " = " + id;
        String SQLQuery = "delete from ignorerecord where id='" + id + "'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return;
    }
 public void deleteRecordcontact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //String SQLQuery = "DELETE * FROM " + TABLE_WISHLIST + " WHERE " + FIELD_W_ITEMCODE + " = " + id;
        String SQLQuery = "delete from contacttorecord where id='" + id + "'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return;
    }
    public void deleteContactToSave(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        //String SQLQuery = "DELETE * FROM " + TABLE_WISHLIST + " WHERE " + FIELD_W_ITEMCODE + " = " + id;
        String SQLQuery = "delete from contacttosave where id='" + id + "'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return;
    }

    public boolean UpdateNotes(String s_data, Integer callerid, String subject) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put("usernotes", s_data);
        contentValues.put("subject", subject);


        long check = db.update("userrecord", contentValues, "callerid" + " ='" + callerid + "'", null);
        //  int i = db.update(TABLE_EMPLOYEE, values, COLUMN_USER_ID + " = " + String.valueOf(userId), null);

        if (check > -1) {
            Log.i("morning ", "morning updated successfully");

            status = true;
        } else {
            Log.i("morning", "morning updated not successful");
        }

        return status;
    }


    // Getting single contact
    public String getContactNotes(int Note) {

        Cursor cursor = null;
        String empName = "";
        try {
            SQLiteDatabase database = getReadableDatabase();
            cursor = database.rawQuery("SELECT usernotes FROM userrecord WHERE callerid=?", new String[]{Note + ""});

            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                empName = cursor.getString(cursor.getColumnIndex("usernotes"));
            }

            return empName;
        } finally {

            cursor.close();
        }
    }

    public String getContactSubject(int id) {

        Cursor cursor = null;
        String empName = "";
        try {
            SQLiteDatabase database = getReadableDatabase();
            cursor = database.rawQuery("SELECT subject FROM userrecord WHERE callerid=?", new String[]{id + ""});

            if (cursor.getCount() > 0) {

                cursor.moveToFirst();
                empName = cursor.getString(cursor.getColumnIndex("subject"));
            }

            return empName;
        } finally {

            cursor.close();
        }
    }

    public ArrayList<CallRecorderModel> getSavedItem() {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " WHERE " + FIELD_SAVED +  "=" + "true"  +
//                " ORDER BY " + FIELD_CALLERID + " DESC";

        String query = "select * from userrecord where save='" + "true" + "'";

        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));
                String upload = c.getString(c.getColumnIndex(FIELD_UPLOAD));
                String delete = c.getString(c.getColumnIndex(FIELD_DALETE));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setUpload(upload);
                recorder.setDelete(delete);
                recorder.setCallDuration(duration);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }
    public ArrayList<CallRecorderModel> getSavedItemAndNotUploaded() {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " WHERE " + FIELD_SAVED +  "=" + "true"  +
//                " ORDER BY " + FIELD_CALLERID + " DESC";

//        String query = "select * from userrecord where save='" + "true" + "'";
        String query = "select * from userrecord where upload='" + "false" + "' AND save='" + "true" + "'";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String upload = c.getString(c.getColumnIndex(FIELD_UPLOAD));
                String delete = c.getString(c.getColumnIndex(FIELD_DALETE));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setUpload(upload);
                recorder.setDelete(delete);
                recorder.setCallDuration(duration);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }
    public ArrayList<CallRecorderModel> getautosaveToCloud() {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " WHERE " + FIELD_SAVED +  "=" + "true"  +
//                " ORDER BY " + FIELD_CALLERID + " DESC";

//        String query = "select * from userrecord where save='" + "true" + "'";
        String query = "select * from userrecord where upload='" + "false" + "'";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String upload = c.getString(c.getColumnIndex(FIELD_UPLOAD));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));
                String delete = c.getString(c.getColumnIndex(FIELD_DALETE));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setUpload(upload);
                recorder.setCallDuration(duration);
                recorder.setDelete(delete);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }
    public boolean UpdatesaveStatus(int customerid, String data) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("save", data);


        long check = db.update("userrecord", contentValues, "callerid" + " ='" + customerid + "'", null);
        //  int i = db.update(TABLE_EMPLOYEE, values, COLUMN_USER_ID + " = " + String.valueOf(userId), null);

        if (check > -1) {
            Log.i("data Update", "data update successfully");

            status = true;
        } else {
            Log.i("data update", "data updation not successful");
        }

        return status;
    }

    public boolean UpdateCloudStatus(int customerid, String data) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("upload", data);


        long check = db.update("userrecord", contentValues, "callerid" + " ='" + customerid + "'", null);
        //  int i = db.update(TABLE_EMPLOYEE, values, COLUMN_USER_ID + " = " + String.valueOf(userId), null);

        if (check > -1) {
            Log.i("data Update", "data update successfully");

            status = true;
        } else {
            Log.i("data update", "data updation not successful");
        }

        return status;
    }

    public boolean UpadetDeleteStatus(int customerid, String data) {
        boolean status = false;

        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(FIELD_DALETE, data);


        long check = db.update("userrecord", contentValues, "callerid" + " ='" + customerid + "'", null);
        //  int i = db.update(TABLE_EMPLOYEE, values, COLUMN_USER_ID + " = " + String.valueOf(userId), null);

        if (check > -1) {
            Log.i("data Update", "data update successfully");

            status = true;
        } else {
            Log.i("data update", "data updation not successful");
        }

        return status;
    }

    /*get perticular user detail*/

    public ArrayList<CallRecorderModel> getParticularUserData(String userNumber) {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
        String query = "select * from userrecord where callernumber = '" + userNumber + "'" + " ORDER BY " + FIELD_CALLERID + " DESC";
//

        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setCallDuration(duration);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }
/*get perticular user detail*/

    public ArrayList<CallRecorderModel> getBlockUser(String userNumber) {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
//        String query = "select * from ignorerecord where number = '" + userNumber + "'" + " ORDER BY " + FIELD_IGNORE_ID + " DESC";
//
  String query = "select * from ignorerecord where number like '%" + userNumber + "%' ";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_IGNORE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_IGNORE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_IGNORE_NUMBER));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallernumber(callernumber);

                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }

    /*get perticular user detail*/

    public ArrayList<CallRecorderModel> getRecordUser(String userNumber) {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
//        String query = "select * from ignorerecord where number = '" + userNumber + "'" + " ORDER BY " + FIELD_IGNORE_ID + " DESC";
//
        String query = "select * from contacttorecord where number like '%" + userNumber + "%' ";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_IGNORE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_IGNORE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_IGNORE_NUMBER));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallernumber(callernumber);

                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }

    public ArrayList<CallRecorderModel> getContactToSave(String userNumber) {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
//        String query = "select * from ignorerecord where number = '" + userNumber + "'" + " ORDER BY " + FIELD_IGNORE_ID + " DESC";
//
        String query = "select * from contacttosave where number like '%" + userNumber + "%' ";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_IGNORE_ID));
                String callername = c.getString(c.getColumnIndex(FIELD_IGNORE_NAME));
                String callernumber = c.getString(c.getColumnIndex(FIELD_IGNORE_NUMBER));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallernumber(callernumber);

                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }
    public int minCallerId() {
        int lId = 0;

        try {
            // Select All Query
            String selectQuery = "SELECT MIN(callerid) FROM " + TABLE_USERRECORDDATA;

            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(selectQuery, null);

            // looping through all rows and adding to list
            if (cursor.moveToFirst()) {
                do {
                    lId = cursor.getInt(0);
                } while (cursor.moveToNext());
            }

            // closing connection
            cursor.close();
            db.close();

            // returning lables

        } catch (Exception e) {

        }
        return lId;
    }

    public ArrayList<CallRecorderModel> getSearchAll(String name) {
//        String query = "SELECT * FROM " + TABLE_USERRECORDDATA + " ORDER BY " + FIELD_CALLERID + " DESC";
//        String  query = "select * from userrecord where callername like '%" + name + "% OR callernumber like %"+name+"%'" ;
        String query = "select * from userrecord where callernumber like '%" + name + "%' or callername like '%" + name + "%' ";
        ArrayList<CallRecorderModel> callRecorderModels = new ArrayList<CallRecorderModel>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor c = database.rawQuery(query, null);
        if (c != null) {
            while (c.moveToNext()) {
                int callerd = c.getInt(c.getColumnIndex(FIELD_CALLERID));
                String callername = c.getString(c.getColumnIndex(FIELD_CALLERNAME));
                String callerimage = c.getString(c.getColumnIndex(FIELD_CALLERIMAGE));
                String callernumber = c.getString(c.getColumnIndex(FIELD_CALLERNUMBER));
                String saved = c.getString(c.getColumnIndex(FIELD_SAVED));
                String duration = c.getString(c.getColumnIndex(FIELD_DURATION));
                String callingdate = c.getString(c.getColumnIndex(FIELD_CALLINGDATE));
                String callingtime = c.getString(c.getColumnIndex(FIELD_CALLINGTIME));
                String callingtype = c.getString(c.getColumnIndex(FIELD_CALLERTYPE));
                String recordingpath = c.getString(c.getColumnIndex(FIELD_CALLERRECORDINGPATH));


                CallRecorderModel recorder = new CallRecorderModel();
                recorder.setCallerid(callerd);
                recorder.setCallername(callername);
                recorder.setCallerimage(callerimage);
                recorder.setSaved(saved);
                recorder.setCallDuration(duration);
                recorder.setCallernumber(callernumber);
//                recorder.setTransactionDate("1470484208929");
                recorder.setTransactionDate(callingdate);
                recorder.setCallingtime(callingtime);
                recorder.setType(callingtype);
                recorder.setRecordingpath(recordingpath);


                Log.d("DBHelper: ", "itemid: " + callerd);


                callRecorderModels.add(recorder);
            }
        }

        return callRecorderModels;

    }

    public void delete() {
        SQLiteDatabase db = this.getWritableDatabase();
        //String SQLQuery = "DELETE * FROM " + TABLE_WISHLIST + " WHERE " + FIELD_W_ITEMCODE + " = " + id;
        String SQLQuery = "delete from userrecord where del='true'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return;
    }

    public int Getdeletevalue(int pos) {
        SQLiteDatabase db = this.getWritableDatabase();
        String SQLQuery = "select '" + FIELD_DALETE + "' from userrecord where '" + FIELD_CALLERID + "'= '" + pos + "'";
        db.execSQL(SQLQuery);
        db.close();
        // return 1;
        return pos;

    }
}
