package example.com.callrecorder.Utils;

/**
 * Created by ravi on 26-10-2016.
 */

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;

public class PreferenceSettings {
    private String CASHTAG = "CashTag";

    private String SELULARDATA_WARNIG = "data";
    private String WIFI_ONLY = "wifi";
    private String AUTOSAVE = "save";
    private String AUTOSAVE_RECORDING = "auto";

    private String NEW_CALL_NOTIFY = "newcall";
    private String SHOW_IMAGE_NOTIFY = "showcall";
    private String AFTER_CALL_NOTIFY = "aftercall";


    private static final String SAVE_RECORDING = "saveRecording";

    private static final String AUDIO_FORMAT = "audio";
    private static final String FILTER_INBOX = "inbox";
    private static final String FILTER_DEFAULT = "default2";
    private static final String RECORD_CALLS = "calls";
    private static final String EXTERNAL_PLAYER = "player";
    private static final String RECORDING_AUTOMATIC_SPEAKER = "speaker";
    private static final String RECORDING_BLUETOOTH = "bluetooth";
    private static final String RECORDING_VOLUMES = "volume";
    private static final String SELULAR_DATA = "data";
    private static final String RECORDING_PATH = "path";

    private static final String DELAY_INCOMING = "incoming";
    private static final String DURATION = "duration";
    private static final String DELAY_OUTGOING = "outgoing";
    private static final String DRIVELOGIN = "drivelogin";


    Context _context;

    private SharedPreferences sp;
    private SharedPreferences.Editor editor;


    public PreferenceSettings(Context context) {
        this._context = context;
        sp = _context.getSharedPreferences(CASHTAG, context.MODE_PRIVATE);
        editor = sp.edit();
    }
    public void setRecordingPath(String save) {
        editor.putString(RECORDING_PATH, save).commit();
    }

    public String getRecordingPath() {
        return sp.getString(RECORDING_PATH, "/sdcard/callrecorder");
    }


    ///////////////////////////////////////////////save Recording////////////////////////////////////////
    public void setSaveRecording(String save) {
        editor.putString(SAVE_RECORDING, save).commit();
    }

    public String getSaveRecording() {
        return sp.getString(SAVE_RECORDING, "Save the recording");
    }


    ///////////////////////////////////////////////Recording Audio Format////////////////////////////////////////
    public void setAudioFormat(String audio) {
        editor.putString(AUDIO_FORMAT, audio).commit();
    }

    public String getAudioFormat() {
        return sp.getString(AUDIO_FORMAT, "1");
    }


    ///////////////////////////////////////////////Filter Inbox////////////////////////////////////////
    public void setFilterInbox(String inbox) {
        editor.putString(FILTER_INBOX, inbox).commit();
    }

    public String getFilterInbox() {
        return sp.getString(FILTER_INBOX, "100");
    }

    ///////////////////////////////////////////////Filter Default mode////////////////////////////////////////
    public void setFilterDefault(String defaul2) {
        editor.putString(FILTER_DEFAULT, defaul2).commit();
    }

    public String getFilterDefault() {
        return sp.getString(FILTER_DEFAULT, "Record all");
    }

    ///////////////////////////////////////////////Filter Default mode////////////////////////////////////////
    public void setSettingRecordCalls(String calls) {
        editor.putString(RECORD_CALLS, calls).commit();
    }

    public String getSettingRecordCalls() {
        return sp.getString(RECORD_CALLS, "");
    }


    /////////////////////////////////////////////// setting record calls////////////////////////////////////////
    public void setSettingExternalPlayer(String player) {
        editor.putString(EXTERNAL_PLAYER, player).commit();
    }

    public String getSettingExternalPlayer() {
        return sp.getString(EXTERNAL_PLAYER, "");
    }

    /////////////////////////////////////////////// setting record calls////////////////////////////////////////
    public void setRecordingSpeaker(String speaker) {
        editor.putString(RECORDING_AUTOMATIC_SPEAKER, speaker).commit();
    }

    public String getRecordingSpeaker() {
        return sp.getString(RECORDING_AUTOMATIC_SPEAKER, "");
    }

    /////////////////////////////////////////////// setting recordng bluetooth////////////////////////////////////////
    public void setRecordingBluetooth(String bluetooth) {
        editor.putString(RECORDING_BLUETOOTH, bluetooth).commit();
    }

    public String getRecordingBluetooth() {
        return sp.getString(RECORDING_BLUETOOTH, "");
    }

    /////////////////////////////////////////////// setting recordng volumes////////////////////////////////////////
    public void setRecordingVolumes(String volumes) {
        editor.putString(RECORDING_VOLUMES, volumes).commit();
    }

    public String getRecordingVolumes() {
        return sp.getString(RECORDING_VOLUMES, "");
    }

    /////selular data///
    public void setSelularData(String selularData) {
        editor.putString(SELULAR_DATA, selularData).commit();
    }

    public String getSelularData() {
        return sp.getString(SELULAR_DATA, "");
    }

    public boolean getSELULARDATA_WARNIG() {
        return sp.getBoolean(SELULARDATA_WARNIG, false);
    }

    public void setSELULARDATA_WARNIG(boolean flag) {
        editor.putBoolean(SELULARDATA_WARNIG, flag).commit();
    }

    public boolean getWifionly() {
        return sp.getBoolean(WIFI_ONLY, false);
    }

    public void setWifionly(boolean flag) {
        editor.putBoolean(WIFI_ONLY, flag).commit();
    }

    public boolean getAUTOSAVE() {
        return sp.getBoolean(AUTOSAVE, false);
    }

    public void setAUTOSAVE(boolean flag) {
        editor.putBoolean(AUTOSAVE, flag).commit();
    }

    public boolean getAUTOSAVE_RECORDING() {
        return sp.getBoolean(AUTOSAVE_RECORDING, true);
    }

    public void setAUTOSAVE_RECORDING(boolean flag) {
        editor.putBoolean(AUTOSAVE_RECORDING, flag).commit();
    }

    public boolean getNEW_CALL_NOTIFY() {
        return sp.getBoolean(NEW_CALL_NOTIFY, true);
    }

    public void setNEW_CALL_NOTIFY(boolean flag) {
        editor.putBoolean(NEW_CALL_NOTIFY, flag).commit();
    }

    public boolean getSHOW_IMAGE_NOTIFY() {
        return sp.getBoolean(SHOW_IMAGE_NOTIFY, false);
    }

    public void setSHOW_IMAGE_NOTIFY(boolean flag) {
        editor.putBoolean(SHOW_IMAGE_NOTIFY, flag).commit();
    }

    public boolean getAFTER_CALL_NOTIFY() {
        return sp.getBoolean(AFTER_CALL_NOTIFY, false);
    }

    public void setAFTER_CALL_NOTIFY(boolean flag) {
        editor.putBoolean(AFTER_CALL_NOTIFY, flag).commit();
    }
///////////////// ////////////////////////

    public void setDelayIncoming(String incoming)
    {
        editor.putString(DELAY_INCOMING, incoming).commit();
    }

    public String getDelayIncoming()
    {
        return sp.getString(DELAY_INCOMING, "3");
    }



    public void setDelayOutgoing(String outgoing)
    {
        editor.putString(DELAY_OUTGOING, outgoing).commit();
    }

    public String getDelayOutgoing()
    {
        return sp.getString(DELAY_OUTGOING, "10");
    }

    public boolean getDriveLogin() {
        return sp.getBoolean(DRIVELOGIN, false);
    }

    public void setDriveLogin(boolean flag) {
        editor.putBoolean(DRIVELOGIN, flag).commit();
    }



    public void setCallDuration(String duration)
    {
        editor.putString(DURATION, duration).commit();
    }

    public String getCallDuration()
    {
        return sp.getString(DURATION, "0");
    }


}